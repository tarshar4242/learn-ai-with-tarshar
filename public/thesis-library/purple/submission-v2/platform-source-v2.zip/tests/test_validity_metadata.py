"""Regression tests for conservative, evidence-linked E2 labels."""
import json
from pathlib import Path
import pytest
from scripts.annotate_validity import annotate, build, STATUSES

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'data/validity/verified-findings.json'


def test_unknown_does_not_become_valid_from_date_or_url():
    doc={'id':'sample','type':'法條','text':'有效日起施行','date':'2026-10-26','url':'https://law.moj.gov.tw/'}
    result=annotate(doc,{})
    assert result['status']=='版本待查'
    assert result['effective_from'] is None
    assert result['superseded_by'] is None


def test_announcement_is_not_marked_stopped_by_keyword():
    doc={'id':'FINT-sample','type':'函釋','text':'他函自即日起停止適用'}
    result=annotate(doc,{})
    assert result['status']=='版本待查'
    assert 'announces_other_interpretations_cessation' in result['validity_flags']


def test_deleted_premise_date_is_not_original_effective_date():
    findings=json.loads(EVIDENCE.read_text())['findings']
    for ident in ('FINT-97','FINT-98','FINT-108'):
        result=annotate({'id':ident,'type':'函釋','text':'第22條'},findings)
        assert result['status']=='前提法條已刪除'
        assert result['status_effective_from']=='2022-01-18'
        assert result['premise_change_promulgated_on']=='2022-01-12'
        assert result['effective_from'] is None
        assert result['superseded_by'] is None


def test_all_documents_are_covered_and_sources_resolve():
    result=build(ROOT/'data/corpus.json',EVIDENCE)
    assert result['counts']['documents']==1781
    assert result['counts']['interpretations']==138
    assert result['counts']['human_verified']==0
    assert result['counts']['status']=={'有效':0,'停止適用':0,'前提法條已刪除':3,'版本待查':1778}
    assert all(d['status'] in STATUSES for d in result['documents'])
    for d in result['documents']:
        assert d['validity_review']=='AI逐筆初篩，非人工法律效力核定'
        assert all(k in d for k in ('status','effective_from','superseded_by'))


def test_stopping_notice_targets_are_separate():
    result=build(ROOT/'data/corpus.json',EVIDENCE)
    docs={d['id']:d for d in result['documents']}
    for ident in ('FINT-42','FINT-62','FINT-65','FINT-96','FINT-111'):
        assert docs[ident]['status']=='版本待查'
        assert docs[ident]['document_role']=='cessation_notice'
        assert docs[ident]['superseded_by'] is None
    assert len(docs['FINT-96']['announced_targets'])==10
    assert docs['FINT-111']['announced_targets'][0]['basis']=='official_document_checked'
    assert len(docs['FINT-62']['announced_targets'])==6
    assert docs['FINT-66']['status']=='版本待查'
    assert docs['FINT-69']['status']=='版本待查'
    assert docs['FINT-66']['partial_cessation_source']=='FINT-62'


def test_old_name_is_only_a_warning_not_a_cessation():
    doc={'id':'FINT-sample','type':'函釋','text':'兩性工作平等法第13條'}
    result=annotate(doc,{})
    assert result['status']=='版本待查'
    assert 'historical_law_name' in result['validity_flags']


def test_duplicate_document_id_is_rejected(tmp_path):
    evidence=tmp_path/'evidence.json'; evidence.write_text('{"findings":{},"sources":{}}')
    corpus=tmp_path/'corpus.json';corpus.write_text(json.dumps({'docs':[{'id':'a'},{'id':'a'}]}))
    with pytest.raises(ValueError,match='Duplicate'):
        build(corpus,evidence)


def test_unmatched_findings_do_not_silently_attach_to_other_documents(tmp_path):
    evidence=tmp_path/'evidence.json';evidence.write_text('{"findings":{"absent":{}},"sources":{}}')
    corpus=tmp_path/'corpus.json';corpus.write_text('{"docs":[{"id":"a"}]}')
    with pytest.raises(ValueError,match='absent ids'):
        build(corpus,evidence)


def test_evidence_hashes_match_retained_pages_and_wrong_documents_are_not_evidence():
    import hashlib
    evidence=json.loads(EVIDENCE.read_text())
    for source in evidence['sources'].values():
        if 'snapshot' in source:
            raw=(EVIDENCE.parent/source['snapshot']).read_bytes()
            assert hashlib.sha256(raw).hexdigest()==source['snapshot_sha256']
    for finding in evidence['findings'].values():
        for key in finding.get('validity_evidence',[]):
            assert not evidence['sources'][key].get('not_supporting_evidence',False)
    snapshots=json.loads((EVIDENCE.parent/'source-snapshots.json').read_text())
    wrong={s['source_id'] for s in snapshots if s.get('identity_matched') is False}
    assert wrong=={'fint108-official','fint93-official'}
