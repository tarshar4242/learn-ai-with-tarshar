#!/usr/bin/env python3
"""把 Notion 課程文稿 + 逐幀筆記合成一份「三合一」自足頁面。

用法：
    python3 merge_notes.py <逐幀筆記資料夾> <Notion 文稿資料夾> --out <整合輸出資料夾>

前置：
- 逐幀筆記資料夾要已經跑過 make_notes.py（裡面有一堆「NN 標題」子資料夾）
- Notion 文稿資料夾要已經跑過 dl_notion_public.py（裡面是 NN｜標題.md）

配對規則：兩邊都用開頭兩位數字（01、02、...）當單元編號來對齊。
只要兩邊都有的單元才會被整合；一邊缺就跳過並回報。

輸出：每支影片一個 HTML，含三個區塊：
    📖 教學文稿（Notion 精華、保留章節與超連結）
    🎞️ 畫面時間軸（來自逐幀筆記）
    📝 完整逐字稿（<details> 摺疊，需要時展開）
最後產一份總 index.html 導覽。
"""
import argparse, glob, html, json, os, re, shutil, urllib.parse

CJK = r"㐀-鿿豈-﫿　-〿＀-￯"
PUNC = {",": "，", "?": "？", "!": "！", ":": "：", ";": "；"}


def norm(t):
    out = []
    for i, ch in enumerate(t):
        if ch in PUNC:
            prev = t[i - 1] if i else ""
            nxt = t[i + 1] if i + 1 < len(t) else ""
            if re.match(f"[{CJK}]", prev) or re.match(f"[{CJK}]", nxt):
                out.append(PUNC[ch])
                continue
        out.append(ch)
    return re.sub(r"[ \t]+", " ", "".join(out)).strip()


def mmss(t):
    return f"{int(t)//60:02d}:{int(t)%60:02d}"


def hhmm(sec):
    m, s = divmod(int(sec), 60)
    return f"{m} 分 {s} 秒"


# ── 極輕量 Markdown → HTML（只處理實際會遇到的：文稿的樣式） ──
def md_to_html(md):
    # 去掉檔頭：從開頭吃到「第一個 --- ... 第二個 ---」（我們的 dl_notion_public.py 輸出格式）
    md = re.sub(r"\A.*?^---\s*\n(?:\s*\n)*---\s*\n", "", md, count=1, flags=re.S | re.M)
    # image attachment 只是佔位，沒有真檔案
    md = re.sub(r"（image：attachment:[^）]+）", "", md)
    md = md.lstrip("\n")

    def inline(s):
        s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)",
                   lambda m: f'<a href="{html.escape(m.group(2))}" target="_blank">{html.escape(m.group(1))}</a>',
                   s)
        s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
        return s

    out, i, lines = [], 0, md.split("\n")
    in_ul = False

    def close_ul():
        nonlocal in_ul
        if in_ul:
            out.append("</ul>")
            in_ul = False

    while i < len(lines):
        s = lines[i].rstrip()
        if not s.strip():
            close_ul(); i += 1; continue
        if s.startswith("## "):
            close_ul(); out.append(f'<h3 class="ch">{inline(html.escape(s[3:]))}</h3>'); i += 1; continue
        if s.startswith("### "):
            close_ul(); out.append(f'<h4 class="sec">{inline(html.escape(s[4:]))}</h4>'); i += 1; continue
        if s.startswith("#### "):
            close_ul(); out.append(f"<h5>{inline(html.escape(s[5:]))}</h5>"); i += 1; continue
        if s.startswith("> ****"):
            i += 1; continue          # 文稿裝飾用的空引用
        if s.startswith("> "):
            close_ul(); out.append(f"<blockquote>{inline(html.escape(s[2:]))}</blockquote>"); i += 1; continue
        m = re.match(r"^\s*- (.+)", s)
        if m:
            if not in_ul:
                out.append("<ul>"); in_ul = True
            out.append(f"<li>{inline(html.escape(m.group(1)))}</li>"); i += 1; continue
        m = re.match(r"^\d+\. (.+)", s)
        if m:
            close_ul()
            items = [m.group(1)]; i += 1
            while i < len(lines):
                m2 = re.match(r"^\d+\. (.+)", lines[i])
                if not m2:
                    break
                items.append(m2.group(1)); i += 1
            out.append("<ol>" + "".join(f"<li>{inline(html.escape(x))}</li>" for x in items) + "</ol>")
            continue
        if s == "---":
            close_ul(); out.append("<hr>"); i += 1; continue
        close_ul()
        out.append(f"<p>{inline(html.escape(s))}</p>")
        i += 1
    close_ul()
    return "\n".join(out)


def paragraphs(segs):
    paras, buf, last = [], [], None
    for s in segs:
        if buf and (sum(len(x) for x in buf) > 170 or (last is not None and s["start"] - last > 2.2)):
            paras.append("".join(buf)); buf = []
        buf.append(norm(s["text"])); last = s["end"]
    if buf:
        paras.append("".join(buf))
    return [p for p in paras if p]


PAGE = """<!doctype html>
<html lang=zh-Hant><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>{{T}}</title>
<style>
:root{--bg:#fbfaf8;--fg:#23201c;--muted:#6f6a63;--line:#e6e1d9;--card:#fff;--accent:#c2410c;--sub:#f3ede2}
@media(prefers-color-scheme:dark){:root{--bg:#16150f;--fg:#ece7de;--muted:#a39c90;--line:#332f27;--card:#1e1c15;--accent:#f59e5b;--sub:#221f16}}
*{box-sizing:border-box}
body{margin:0;padding:1.5rem 1rem 5rem;background:var(--bg);color:var(--fg);
 font:16px/1.85 "Helvetica Neue","PingFang TC","Noto Sans TC",sans-serif;max-width:820px;margin-inline:auto}
header{margin-bottom:2rem;padding-bottom:1.4rem;border-bottom:2px solid var(--line)}
h1{font-size:1.55rem;line-height:1.4;margin:0 0 .6rem}
h2{font-size:1.25rem;margin:2.8rem 0 1rem;padding:.5rem .7rem;background:var(--sub);border-radius:6px;border-left:4px solid var(--accent)}
h3.ch{font-size:1.1rem;margin:2rem 0 .8rem;color:var(--accent);border-bottom:1px solid var(--line);padding-bottom:.35rem}
h4.sec{font-size:1rem;margin:1.5rem 0 .5rem;color:var(--fg)}
article h4{font-size:1rem;margin:0 0 .7rem;color:var(--accent);font-variant-numeric:tabular-nums}
article h4 .t{color:var(--muted);font-weight:400;margin-left:.3rem}
h5{font-size:.94rem;margin:1rem 0 .3rem;color:var(--muted)}
p{margin:.55rem 0}
.meta{color:var(--muted);font-size:.85rem;line-height:1.7}
.note{color:var(--muted);font-size:.85rem;padding:.5rem .8rem;background:var(--sub);border-radius:4px;margin:.3rem 0 1rem}
code{font-size:.85em;background:var(--card);padding:.1em .35em;border-radius:3px;word-break:break-all}
a{color:var(--accent)}
blockquote{margin:.7rem 0;padding:.4rem .9rem;border-left:3px solid var(--accent);background:var(--card);border-radius:4px}
blockquote p{margin:.2rem 0}
nav.jump{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:1rem}
nav.jump a{padding:.35rem .8rem;background:var(--sub);border-radius:20px;text-decoration:none;font-size:.85rem}
nav.jump a:hover{background:var(--accent);color:#fff}
ul,ol{padding-left:1.6rem}
li{margin:.25rem 0}
ul.idx{list-style:none;padding:0;margin:0 0 1.3rem;columns:2;column-gap:1.6rem}
@media(max-width:600px){ul.idx{columns:1}}
ul.idx li{font-size:.9rem;break-inside:avoid;margin:.2rem 0}
ul.idx a{text-decoration:none;font-variant-numeric:tabular-nums}
article{margin:0 0 2rem;padding-top:.8rem;border-top:1px solid var(--line)}
img{width:100%;height:auto;border-radius:6px;border:1px solid var(--line);display:block;margin:.3rem 0 .9rem}
.card{background:var(--card);border:1px solid var(--line);border-left:3px solid var(--accent);
 border-radius:5px;padding:.6rem .9rem;margin:.5rem 0 .9rem}
.card p{margin:.15rem 0;font-size:.93rem}
.lbl{font-size:.75rem;letter-spacing:.12em;color:var(--muted);margin:.9rem 0 .2rem}
details{margin-top:1rem;background:var(--card);border:1px solid var(--line);border-radius:5px;padding:.4rem .8rem}
summary{cursor:pointer;color:var(--muted);font-size:.9rem;padding:.3rem 0}
.txbox{max-height:60vh;overflow:auto;padding:.8rem;background:var(--bg);border-radius:4px;margin-top:.6rem}
.tx{font-size:.85rem;line-height:1.7;padding:.15rem 0}
.tx span{color:var(--accent);font-variant-numeric:tabular-nums;margin-right:.4rem;font-size:.8rem}
hr{border:0;border-top:1px solid var(--line);margin:1.5rem 0}
</style></head><body>
{{BODY}}
</body></html>"""

INDEX_CSS = """:root{--bg:#fbfaf8;--fg:#23201c;--muted:#6f6a63;--line:#e6e1d9;--card:#fff;--accent:#c2410c;--sub:#f3ede2}
@media(prefers-color-scheme:dark){:root{--bg:#16150f;--fg:#ece7de;--muted:#a39c90;--line:#332f27;--card:#1e1c15;--accent:#f59e5b;--sub:#221f16}}
*{box-sizing:border-box}
body{margin:0;padding:2rem 1rem 5rem;background:var(--bg);color:var(--fg);
 font:16px/1.8 "Helvetica Neue","PingFang TC","Noto Sans TC",sans-serif;max-width:1000px;margin-inline:auto}
h1{font-size:1.7rem;margin:0 0 .4rem}
.sub{color:var(--muted);font-size:.9rem;margin:0 0 1.6rem}
.note{background:var(--sub);border-radius:6px;padding:.7rem 1rem;font-size:.88rem;color:var(--fg);margin:0 0 2rem;border-left:3px solid var(--accent)}
.note b{color:var(--accent)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.1rem}
.tile{display:flex;flex-direction:column;background:var(--card);border:1px solid var(--line);
 border-radius:9px;overflow:hidden;text-decoration:none;color:inherit;transition:.15s}
.tile:hover{border-color:var(--accent);transform:translateY(-2px)}
.thumb{aspect-ratio:16/9;background:var(--line);overflow:hidden}
.thumb img{width:100%;height:100%;object-fit:cover;display:block}
.body{padding:.8rem 1rem 1rem}
.no{font-size:.72rem;letter-spacing:.16em;color:var(--accent);font-weight:600}
.tile h3{font-size:.98rem;line-height:1.5;margin:.25rem 0 .5rem}
.stat{font-size:.78rem;color:var(--muted);font-variant-numeric:tabular-nums}
.foot{margin-top:2.5rem;padding-top:1.2rem;border-top:1px solid var(--line);color:var(--muted);font-size:.85rem}
.foot b{color:var(--fg)}"""


def build_one(no, note_dir, doc_md_path, out_root):
    """回傳 (no, title, n_frames, n_segs, thumb) 或 None"""
    manifest_path = os.path.join(note_dir, "..", "..", "manifest.json")  # 目前不存在，改讀 frames/*.jpg
    # 從 note_dir 讀畫面清單、逐字稿（都在同一資料夾）
    # note_dir 結構：frames/*.jpg + 筆記.html + 筆記.md + 逐字稿.txt
    # 我們需要「畫面時間戳＋種類」，這只有在原本的 make_notes.py 中繼檔裡才有
    # 因此改從「筆記.md」反推（時間戳寫在 ### 標題裡：### 1  00:03）
    md = open(os.path.join(note_dir, "筆記.md"), encoding="utf-8").read()
    tx_lines = open(os.path.join(note_dir, "逐字稿.txt"), encoding="utf-8").read().splitlines()

    # 從 md 拆出每段的時間、圖檔、字卡文字、口述段落
    sections = []
    audio_only = "**這是語音單元**" in md
    dur_m = re.search(r"影片長度 (\d+) 分 (\d+) 秒", md)
    dur = int(dur_m.group(1)) * 60 + int(dur_m.group(2)) if dur_m else 0
    n_frames_m = re.search(r"關鍵畫面 (\d+) 張", md)
    n_frames = int(n_frames_m.group(1)) if n_frames_m else 0
    n_segs_m = re.search(r"逐字稿 (\d+) 段", md)
    n_segs = int(n_segs_m.group(1)) if n_segs_m else 0

    # 按 ### N  MM:SS 分段
    parts = re.split(r"^### (\d+)\s+(\d+):(\d+)\s*$", md, flags=re.M)
    # parts[0] 是前言，之後每四個一組：n、mm、ss、body
    for i in range(1, len(parts), 4):
        n_seg, mm, ss = parts[i], parts[i + 1], parts[i + 2]
        body = parts[i + 3]
        t = int(mm) * 60 + int(ss)
        img_m = re.search(r"!\[[^\]]*\]\(frames/([^)]+)\)", body)
        img = img_m.group(1) if img_m else None
        # 畫面文字（可能沒有）
        card = re.search(r"\*\*畫面文字\*\*\s*\n\s*\n((?:>.+\n?)+)", body)
        card_text = ""
        if card:
            card_text = "\n".join(re.sub(r"^>\s*", "", l) for l in card.group(1).splitlines() if l.strip())
        # 口述段落
        speak = re.search(r"\*\*口述內容\*\*\s*\n\s*\n(.*?)(?=\n### |\Z)", body, re.S)
        speak_text = speak.group(1).strip() if speak else ""
        sections.append({"n": n_seg, "t": t, "img": img, "card": card_text, "speak": speak_text})

    # 建輸出資料夾
    stem_m = re.match(r"^\d+\s+(.+)$", os.path.basename(note_dir.rstrip("/")))
    title = stem_m.group(1) if stem_m else os.path.basename(note_dir.rstrip("/"))
    out_dir = os.path.join(out_root, f"{no} {title}")
    img_out = os.path.join(out_dir, "frames")
    os.makedirs(img_out, exist_ok=True)
    for f in glob.glob(os.path.join(img_out, "*.jpg")):
        os.remove(f)
    for f in glob.glob(os.path.join(note_dir, "frames", "*.jpg")):
        shutil.copy(f, img_out)

    # 教學文稿
    doc_md = open(doc_md_path, encoding="utf-8").read()
    src_url_m = re.search(r"https://www\.notion\.so/\w+", doc_md)
    src_url = src_url_m.group() if src_url_m else "#"
    doc_html = md_to_html(doc_md)

    # 畫面時間軸
    tl = []
    for s in sections:
        tl.append(f'<article id="t{s["n"]}"><h4>{s["n"]}　<span class=t>{mmss(s["t"])}</span></h4>')
        if s["img"]:
            tl.append(f'<img src="frames/{html.escape(s["img"])}" loading=lazy alt="">')
            if s["card"]:
                tl.append('<div class=card><div class=lbl>畫面文字</div>' +
                          "".join(f"<p>{html.escape(l)}</p>" for l in s["card"].splitlines() if l.strip()) +
                          "</div>")
        tl.append('<div class=lbl>口述內容</div>')
        for p in s["speak"].split("\n\n"):
            p = p.strip()
            if p:
                tl.append(f"<p>{html.escape(p)}</p>")
        tl.append("</article>")

    # 完整逐字稿
    tx = []
    for line in tx_lines:
        m = re.match(r"^\[(\d\d:\d\d)\] (.+)$", line)
        if m:
            tx.append(f"<div class=tx><span>[{m.group(1)}]</span> {html.escape(m.group(2))}</div>")
    tx_html = "\n".join(tx)
    tx_chars = sum(len(t) for t in tx)

    # 畫面索引
    idx = "".join(f'<li><a href="#t{s["n"]}"><b>{mmss(s["t"])}</b></a></li>' for s in sections)

    body = f"""
<header>
  <h1>{html.escape(no)}｜{html.escape(title)}</h1>
  <p class=meta>影片長度 {hhmm(dur)}　關鍵畫面 {n_frames} 張　逐字稿 {n_segs} 段<br>
  文稿來源：<a href="{src_url}" target=_blank>Notion 課程頁</a>　整理：知臨</p>
  <nav class=jump>
    <a href="#doc">📖 教學文稿</a>
    <a href="#tl">🎞️ 畫面時間軸</a>
    <a href="#tx">📝 完整逐字稿</a>
  </nav>
</header>

<section id=doc>
<h2>教學文稿</h2>
<p class=note>來自 Notion 課程頁；保留原文結構與超連結。</p>
{doc_html}
</section>

<section id=tl>
<h2>畫面時間軸</h2>
<p class=note>從影片抓的關鍵畫面＋字卡文字＋該時段口述。{"<br>這是語音單元，畫面全程固定，改依時間分段。" if audio_only else ""}</p>
<ul class=idx>{idx}</ul>
{"".join(tl)}
</section>

<section id=tx>
<h2>完整逐字稿</h2>
<details><summary>展開完整逐字稿（{n_segs} 段，共約 {tx_chars} 字）</summary>
<div class=txbox>{tx_html}</div>
</details>
</section>
"""

    open(os.path.join(out_dir, "整合筆記.html"), "w", encoding="utf-8").write(
        PAGE.replace("{{T}}", html.escape(f"{no}｜{title}")).replace("{{BODY}}", body))

    thumb = sections[0]["img"] if sections and sections[0]["img"] else ""
    return no, title, n_frames, n_segs, thumb, audio_only


def build_index(rows, out_root, series_title):
    q = urllib.parse.quote
    tiles = []
    for no, title, nf, ns, thumb, audio_only in rows:
        d = f"{no} {title}"
        th = f'<img src="{q(d)}/frames/{q(thumb)}" loading=lazy alt="">' if thumb else ""
        tag = "語音單元" if audio_only else f"{nf} 張畫面"
        tiles.append(f'''<a class=tile href="{q(d)}/整合筆記.html">
  <div class=thumb>{th}</div>
  <div class=body>
    <div class=no>{html.escape(no)}</div>
    <h3>{html.escape(title)}</h3>
    <div class=stat>{tag}　逐字稿 {ns} 段</div>
  </div></a>''')

    page = f"""<!doctype html>
<html lang=zh-Hant><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>{html.escape(series_title)}｜整合筆記</title>
<style>{INDEX_CSS}</style></head><body>
<h1>{html.escape(series_title)}</h1>
<p class=sub>整合筆記　共 {len(rows)} 支影片　整理：知臨</p>
<div class=note><b>三合一頁面：</b>每支影片打開就有三個區塊 — 📖 <b>教學文稿</b>（Notion 精華、含超連結）｜🎞️ <b>畫面時間軸</b>（截圖＋字卡文字＋該時段口述）｜📝 <b>完整逐字稿</b>（摺疊，需要時打開）。頂端有三個跳轉按鈕。</div>
<div class=grid>
{chr(10).join(tiles)}
</div>
<div class=foot>
<p><b>為什麼多做一份整合筆記：</b>逐幀筆記給你「老師怎麼講」，但沒有章節結構和超連結；Notion 文稿有結構有連結，但沒畫面、沒有實際口述。整合版把兩份互補的東西合成一頁自足文件，以後只看這份就夠。</p>
<p><b>原本的兩份還在</b>（逐幀筆記與 Notion 文稿），需要單看時可以用。</p>
<p>付費課程內容，請勿外流。</p>
</div>
</body></html>"""
    open(os.path.join(out_root, "index.html"), "w", encoding="utf-8").write(page)


def verify(out_root, rows):
    bad = []
    for no, title, *_ in rows:
        d = os.path.join(out_root, f"{no} {title}")
        h_path = os.path.join(d, "整合筆記.html")
        if not os.path.exists(h_path):
            bad.append(f"{no} 缺整合筆記.html"); continue
        h = open(h_path, encoding="utf-8").read()
        for sec in ("id=doc", "id=tl", "id=tx"):
            if sec not in h:
                bad.append(f"{no} 缺 {sec}")
        for s in re.findall(r'<img src="([^"]+)"', h):
            if not os.path.exists(os.path.join(d, html.unescape(s))):
                bad.append(f"{no} 圖片斷 {s}")
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("notes", help="逐幀筆記資料夾（含各單元子夾）")
    ap.add_argument("docs", help="Notion 文稿資料夾")
    ap.add_argument("--out", required=True, help="整合輸出資料夾")
    ap.add_argument("--title", default="課程整合筆記", help="總索引標題")
    a = ap.parse_args()

    # 逐幀筆記子夾：命名為「NN 標題」
    note_dirs = {}
    for d in sorted(os.listdir(a.notes)):
        p = os.path.join(a.notes, d)
        m = re.match(r"^(\d+)\s+", d)
        if m and os.path.isdir(p) and os.path.exists(os.path.join(p, "筆記.md")):
            note_dirs[m.group(1)] = p

    # Notion 文稿：命名為「NN｜標題.md」
    docs = {}
    for f in sorted(os.listdir(a.docs)):
        m = re.match(r"^(\d+)｜", f)
        if m and f.endswith(".md"):
            docs[m.group(1)] = os.path.join(a.docs, f)

    both = sorted(set(note_dirs) & set(docs))
    only_notes = sorted(set(note_dirs) - set(docs))
    only_docs = sorted(set(docs) - set(note_dirs))

    print(f"可整合 {len(both)} 支；只有逐幀筆記 {len(only_notes)}；只有文稿 {len(only_docs)}")
    if only_notes:
        print(f"  只有逐幀筆記（跳過）：{only_notes}")
    if only_docs:
        print(f"  只有文稿（跳過）：{only_docs}")
    if not both:
        print("沒有可整合的單元。編號兩邊要對得起來（開頭兩位數字）。")
        return

    os.makedirs(a.out, exist_ok=True)
    rows = []
    for no in both:
        r = build_one(no, note_dirs[no], docs[no], a.out)
        if r:
            rows.append(r)
            print(f"  整合 {no} — 畫面 {r[2]}、逐字稿 {r[3]} 段")

    build_index(rows, a.out, a.title)
    bad = verify(a.out, rows)
    print("④ 自檢：" + ("全部通過" if not bad else "有問題：\n  " + "\n  ".join(bad)))
    print(f"\n完成 → {os.path.join(a.out, 'index.html')}")


if __name__ == "__main__":
    main()
