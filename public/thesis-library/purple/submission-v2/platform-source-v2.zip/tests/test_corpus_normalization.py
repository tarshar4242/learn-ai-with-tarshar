"""E1 regression tests: real corpus evidence plus conservative deletion mapping."""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.normalize_corpus import (  # noqa: E402
    SOURCE_SHA256, build, corpus_statistics, json_bytes, literal_statistics,
    normalize_corpus, normalize_document, sha256,
)

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / "data/normalization" / f"source-{SOURCE_SHA256}.json"


def document(text, kind="指引"):
    return {"id": "fixture", "law": "標題", "no": "第 1 頁", "type": kind, "text": text}


def assert_mapping(mapping):
    raw = mapping["raw_text"]
    normalized = mapping["normalized_text"]
    restored = "".join(raw[start:end] for _, _, start, end in mapping["segments"])
    assert restored == normalized
    expected_offset = 0
    covered = set()
    for norm_start, norm_end, raw_start, raw_end in mapping["segments"]:
        assert norm_start == expected_offset
        assert norm_end - norm_start == raw_end - raw_start
        assert normalized[norm_start:norm_end] == raw[raw_start:raw_end]
        expected_offset = norm_end
        covered.update(range(raw_start, raw_end))
    assert expected_offset == len(normalized)
    deleted = set()
    for deletion in mapping["deleted_spans"]:
        deleted.update(range(deletion["raw_start"], deletion["raw_end"]))
    assert covered.isdisjoint(deleted)
    assert covered | deleted == set(range(len(raw)))


def test_cjk_join_preserves_paragraphs_punctuation_and_width():
    raw = "企業雇\r\n主\r\n\r\n第二段\n\n第三段。\n第四段\nＡＢＣ１２３ 30日\n中文"
    result, mapping = normalize_document(document(raw))
    assert result["text"] == "企業雇主\n\n第二段\n\n第三段。\n第四段\nＡＢＣ１２３ 30日中文"
    assert result["text"].count("\n\n") == 2
    assert_mapping(mapping)


def test_no_join_across_indentation_or_whitespace_only_blank_lines():
    result, mapping = normalize_document(document("第一段\n \n第二段\n  第三段\nABC\n12"))
    assert result["text"] == mapping["raw_text"]
    assert_mapping(mapping)


def test_identical_abstract_deduplicated_before_structural_separator_is_joined():
    result, mapping = normalize_document(document("要旨：企業雇\r\n主\n全文：企業雇\n主", "函釋"))
    assert result["text"] == "要旨：企業雇主"
    assert result["type"] == "函釋要旨索引"
    assert mapping["duplicate_abstract_removed"]
    assert_mapping(mapping)
    assert normalize_document(result)[0] == result


def test_nonidentical_full_text_not_removed():
    result, mapping = normalize_document(document("要旨：摘要。\n全文：另有完整內容。", "函釋"))
    assert result["type"] == "函釋"
    assert result["text"] == "要旨：摘要。\n全文：另有完整內容。"
    assert not mapping["duplicate_abstract_removed"]
    assert_mapping(mapping)


def test_literal_statistics_is_exact_separate_fields_nonoverlapping():
    corpus = {"docs": [{"id": "x", "law": "育嬰", "no": "", "text": "育嬰育嬰 aaa ＡＢＣ"}]}
    assert literal_statistics(corpus, "育嬰")["occurrences"] == 3
    assert literal_statistics(corpus, "aa")["occurrences"] == 1
    assert literal_statistics(corpus, "ABC")["matched_documents"] == 0
    assert literal_statistics(corpus, "育嬰育嬰育嬰")["matched_documents"] == 0


def test_real_corpus_changes_are_deletions_and_idempotent():
    raw = SNAPSHOT.read_bytes()
    assert sha256(raw) == SOURCE_SHA256
    original = json.loads(raw)
    candidate, mappings = normalize_corpus(original)
    assert normalize_corpus(candidate)[0] == candidate
    assert len(candidate["docs"]) == 1781
    assert [d["id"] for d in candidate["docs"]] == [d["id"] for d in original["docs"]]
    assert corpus_statistics(original)["cjk_hard_break_documents"] == 299
    assert corpus_statistics(candidate)["cjk_hard_break_documents"] == 0
    assert corpus_statistics(original)["duplicate_abstract_documents"] == 138
    assert corpus_statistics(candidate)["duplicate_abstract_documents"] == 0
    assert sum(d["type"] == "函釋要旨索引" for d in candidate["docs"]) == 138
    assert corpus_statistics(candidate)["cr_characters"] == 0
    for old, new, mapping in zip(original["docs"], candidate["docs"], mappings):
        assert_mapping(mapping)
        assert {k: v for k, v in old.items() if k not in ("text", "type")} == {k: v for k, v in new.items() if k not in ("text", "type")}
    guide = next(d for d in candidate["docs"] if d["id"] == "G2____-p2-1")
    assert "企業雇主" in guide["text"]
    assert json_bytes(candidate) == (SNAPSHOT.parent / "corpus-normalized.json").read_bytes()


@pytest.mark.parametrize("query,documents,occurrences", [("育嬰", 41, 107), ("育嬰留職停薪", 38, 92)])
def test_legacy_development_baseline_is_preserved(query, documents, occurrences):
    old = json.loads(SNAPSHOT.read_bytes())
    count = literal_statistics(old, query)
    assert count["matched_documents"] == documents
    assert count["occurrences"] == occurrences


def test_build_refuses_bad_hash_and_is_byte_reproducible(tmp_path):
    with pytest.raises(ValueError, match="Source SHA256 mismatch"):
        build(SNAPSHOT, tmp_path, "wrong")
    first = build(SNAPSHOT, tmp_path)
    saved = {p.name: p.read_bytes() for p in tmp_path.iterdir()}
    second = build(SNAPSHOT, tmp_path)
    assert first == second
    assert saved == {p.name: p.read_bytes() for p in tmp_path.iterdir()}


@pytest.mark.parametrize("query,documents,occurrences", [("育嬰", 41, 77), ("育嬰留職停薪", 41, 76), ("育嬰假如何請", 0, 0)])
def test_normalized_development_counts(query, documents, occurrences):
    new = json.loads((SNAPSHOT.parent / "corpus-normalized.json").read_bytes())
    count = literal_statistics(new, query)
    assert count["matched_documents"] == documents
    assert count["occurrences"] == occurrences
