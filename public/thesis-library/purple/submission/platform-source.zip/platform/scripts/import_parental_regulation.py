"""Import a bounded official regulation snapshot into both groups' corpus."""
from pathlib import Path
import re,html,json,hashlib,datetime
ROOT=Path(__file__).resolve().parents[1]
def import_html(source:Path):
    raw=source.read_text(encoding='utf-8')
    law='育嬰留職停薪實施辦法'
    if law not in html.unescape(raw) or '114 年 11 月 21 日修正' not in raw:raise ValueError('Unexpected regulation or version')
    rows=re.findall(r'<div class="col-no">(.*?)<div class="col-data">(.*?)</div>',raw,re.S)
    docs=[]
    for head,body in rows:
        match=re.search(r'flno=(\d+)',head);text=re.search(r'<pre>(.*?)</pre>',body,re.S)
        if not match or not text:continue
        n=match.group(1)
        docs.append({'id':f'purple-FL015153-{n}','law':law,'no':f'第 {n} 條','text':html.unescape(text.group(1)).replace('\r\n','\n').strip(),'type':'法條','url':f'https://laws.mol.gov.tw/FLAW/FLAWDOC01.aspx?id=FL015153&flno={n}','date':'2025-11-21','chapter':'','pcode':'FL015153'})
    if len(docs)!=9:raise ValueError('Expected 9 articles')
    dest=ROOT/'data/imports';dest.mkdir(exist_ok=True)
    (dest/'FL015153_20251121.html').write_text(raw,encoding='utf-8')
    (dest/'FL015153_20251121.json').write_text(json.dumps({'source_url':'https://laws.mol.gov.tw/FLAW/FLAWDAT0202.aspx?id=FL015153','fetched_at':datetime.datetime.now().astimezone().isoformat(),'html_sha256':hashlib.sha256(raw.encode()).hexdigest(),'docs':docs},ensure_ascii=False,indent=2),encoding='utf-8')
    path=ROOT/'data/corpus.json';c=json.loads(path.read_text())
    if any(d.get('pcode')=='FL015153' for d in c['docs']):raise ValueError('Already imported')
    before=hashlib.sha256(path.read_bytes()).hexdigest();c['docs']+=docs
    c['purple_revision']='2026-10-22-development-2';path.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest=json.loads((ROOT/'data/manifest.json').read_text());manifest['seed_sha256']=before;manifest['sha256']=hashlib.sha256(path.read_bytes()).hexdigest();manifest['documents']=len(c['docs']);manifest['additions']=[{'law':law,'revision':'2025-11-21','articles':9,'source_file':'data/imports/FL015153_20251121.json','reason':'已看過開發題暴露申請程序法源缺漏；正式測試不得重用此開發題冒充未見題。'}]
    (ROOT/'data/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print('imported',len(docs),'total',len(c['docs']),'sha',manifest['sha256'])
if __name__=='__main__':
    import sys
    import_html(Path(sys.argv[1]))
