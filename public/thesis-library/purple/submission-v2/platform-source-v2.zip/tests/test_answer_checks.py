"""E3/E4: adversarial fixtures, no paid API; lexical warnings are not fact checking."""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.answer_checks import boundary_mismatches, number_value
from app.engine import Engine
import pytest

SOURCE = '育嬰留職停薪期間在三十日以上者，應於十日前提出申請。未滿三歲之子女。不得拒絕。'

@pytest.fixture
def eng(tmp_path):
    p = tmp_path / 'data'; p.mkdir()
    docs = [{'id':'good','law':'測試條文','no':'第1條','text':SOURCE,'status':'版本待查'},
            {'id':'other','law':'別的條文','no':'第2條','text':'獨屬其他文件的文字。'}]
    (p/'corpus.json').write_text(json.dumps({'docs':docs},ensure_ascii=False))
    return Engine(tmp_path, llm=object())


def validate(eng, text, quote, citations=None):
    res, trace = {'warnings':[]}, {}
    out = eng._validate_answer({'status':'answered','points':[{'text':text,'quote':quote,
                              'citations':citations or ['good']}]}, {'good','other'},res,trace)
    return out,trace

@pytest.mark.parametrize('value,expected',[('三十','30'),('三','3'),('一百零一','101'),('十','10'),('一億','100000000'),('三〇','30'),('30','30')])
def test_numbers(value,expected):
    assert number_value(value)==expected


def test_boundary_change_warns_and_retains(eng):
    out,tr=validate(eng,'超過 30 日應於 10 日前提出申請。',SOURCE)
    assert out['status']=='answered' and out['points']
    assert tr['boundary_mismatch'][0]['key']==['超過','30','日','']
    assert out['warnings']


def test_identical_boundary_arabic_and_chinese_pass(eng):
    out,tr=validate(eng,'30 日以上，應於 10 日前提出申請。',SOURCE)
    assert not tr['boundary_mismatch'] and not out['warnings']


def test_other_qualifiers_and_modality():
    for changed in ['30日以下','30日以內','滿三歲','三歲後','可於十日前提出申請']:
        assert boundary_mismatches(changed,[SOURCE])
    assert not boundary_mismatches('未滿3歲，不得拒絕',[SOURCE])
    assert boundary_mismatches('得拒絕',[SOURCE])


def test_fake_valid_id_claim_with_missing_quote_flagged(eng):
    out,tr=validate(eng,'所有人都可以無條件領取一億元。','')
    assert out['status']=='answered' # warn, not silently delete
    assert tr['quote_checks'][0]['reason']=='missing_quote'
    assert tr['boundary_mismatch']

@pytest.mark.parametrize('quote',['不存在的原文','獨屬其他文件的文字。','  ',None])
def test_wrong_quote_or_uncited_doc_fails(eng,quote):
    out,tr=validate(eng,'這是測試',quote)
    assert not tr['quote_checks'][0]['matched']
    assert '原文片段不符' in out['warnings'][0]


def test_real_quote_does_not_prove_entailment(eng):
    out,tr=validate(eng,'法律保證這位申請人一定通過。',SOURCE)
    assert tr['quote_checks'][0]['matched']
    assert not tr['boundary_mismatch'] # Known remaining limitation: false nonnumeric claim.
    assert out['status']=='answered'


def test_citation_id_rejection_still_applies(eng):
    out,tr=validate(eng,'申請','原文',['made-up'])
    assert out['status']=='insufficient'
    assert tr['validation']['invalid_citations']==['made-up']


def test_url_only_point_not_displayed_as_answer(eng):
    out,tr=validate(eng,'https://example.com',SOURCE)
    assert out['status']=='insufficient' and tr['validation']['points_kept']==0


def test_validity_sent_and_exposed_equally(eng):
    doc=eng.docs[0]
    assert '版本待查' in eng._evidence_block([(doc,1.0)])
    assert eng.literal('育嬰')['hits'][0]['status']==eng.document('good')['status']=='版本待查'
    out,tr=validate(eng,'三十日以上',SOURCE)
    assert out['citations'][0]['status']=='版本待查'


def test_thousands_not_truncated_to_zero():
    assert boundary_mismatches('1,000元以上',['0元以上'])
    assert not boundary_mismatches('1,000元以上',['一千元以上'])
    assert not boundary_mismatches('10.0日以上',['十日以上'])
    assert boundary_mismatches('未達六個月',['六個月'])
    assert boundary_mismatches('不應拒絕',['應拒絕'])


def test_display_point_numbers_after_drop(eng):
    out=eng._validate_answer({'status':'answered','points':[
        {'text':'被刪掉','citations':['bad']},
        {'text':'超過30日','citations':['good'],'quote':'不存在'}]},
        {'good'},{'warnings':[]},{})
    point=out['points'][0]
    assert point['quote_check']['point']==1
    assert point['quote_check']['original_point']==2
    assert any('第 1 點' in w for w in out['warnings'])


def test_negative_comparison_not_lost():
    assert boundary_mismatches('超過30日',['不超過三十日'])
    assert boundary_mismatches('少於六個月',['不少於六個月'])
    assert not boundary_mismatches('不超過30日',['不超過三十日'])
