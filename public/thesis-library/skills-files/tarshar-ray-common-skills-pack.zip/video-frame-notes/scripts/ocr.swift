import Foundation
import Vision
import AppKit

// 用 macOS 內建 Vision 做繁中 OCR；輸入圖片路徑，輸出純文字
let args = CommandLine.arguments.dropFirst()
for path in args {
    guard let img = NSImage(contentsOfFile: path),
          let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
        print("<<<FILE:\(path)>>>")
        continue
    }
    let req = VNRecognizeTextRequest()
    req.recognitionLevel = .accurate
    req.recognitionLanguages = ["zh-Hant", "zh-Hans", "en-US"]
    req.usesLanguageCorrection = true
    let handler = VNImageRequestHandler(cgImage: cg, options: [:])
    var lines: [String] = []
    do {
        try handler.perform([req])
        for obs in (req.results ?? []) {
            if let top = obs.topCandidates(1).first, top.confidence > 0.3 {
                lines.append(top.string)
            }
        }
    } catch { }
    print("<<<FILE:\(path)>>>")
    print(lines.joined(separator: "\n"))
}
