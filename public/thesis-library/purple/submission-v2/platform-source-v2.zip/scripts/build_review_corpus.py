"""Rebuild the one A/B corpus from the retained original and E2 metadata."""
import hashlib
import json
from pathlib import Path
from normalize_corpus import normalize_corpus, json_bytes, SOURCE_SHA256

ROOT = Path(__file__).resolve().parents[1]

def main():
    raw = (ROOT/'data/normalization/source-3beff8975506e157fbab89e61035788171909a0b0eb4fae16ec9550be67674c0.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == SOURCE_SHA256
    candidate, _ = normalize_corpus(json.loads(raw))
    metadata = json.loads((ROOT/'data/validity/document-metadata.json').read_text())
    by_id = {d['id']:d for d in metadata['documents']}
    assert len(by_id)==len(candidate['docs'])
    findings=json.loads((ROOT/'data/validity/verified-findings.json').read_text())['sources']
    for d in candidate['docs']:
        d.update(by_id[d['id']])
        d['validity_note'] = d.pop('validity_review_note')
        d['validity_sources'] = [dict(source_id=k, **findings[k]) for k in d.pop('validity_evidence')]
        # Keep original source URL, while linking confirmed exact-document lookups
        # in BOTH groups. Source text and retrieval units are unchanged.
        exact = [r for r in d['validity_sources'] if r['source_id'].endswith('-exact-number')]
        if exact:
            d['original_url'] = d.get('url')
            d['url'] = exact[0]['url']
    normalized_hash = hashlib.sha256((ROOT/'data/normalization/corpus-normalized.json').read_bytes()).hexdigest()
    output = json_bytes(candidate)
    (ROOT/'data/corpus.json').write_bytes(output)
    manifest_path=ROOT/'data/manifest.json'
    manifest=json.loads(manifest_path.read_text())
    manifest.update(sha256=hashlib.sha256(output).hexdigest(),
        original_sha256=SOURCE_SHA256, normalized_text_candidate_sha256=normalized_hash,
        normalization={'version':'e1-common-corpus-normalization-v1',
            'shared_by':['A','B'],'query_normalization':'none',
            'full_half_width_conversion':False,'raw_snapshot':'data/normalization/source-3beff8975506e157fbab89e61035788171909a0b0eb4fae16ec9550be67674c0.json',
            'offset_mapping':'data/normalization/offset-mapping.jsonl'},
        validity={'metadata':'data/validity/document-metadata.json',
            'metadata_sha256':hashlib.sha256((ROOT/'data/validity/document-metadata.json').read_bytes()).hexdigest(),
            'counts':metadata['counts'], 'review_level':metadata['review_level']})
    # Actual map filename follows E1 script output.
    maps=list((ROOT/'data/normalization').glob('*map*.jsonl'))
    if maps: manifest['normalization']['offset_mapping']=str(maps[0].relative_to(ROOT))
    manifest_path.write_bytes(json_bytes(manifest))
    print(json.dumps({'original':SOURCE_SHA256,'normalized_text':normalized_hash,
                      'final':manifest['sha256'],'documents':len(candidate['docs'])},indent=2))

if __name__=='__main__':main()
