#!/usr/bin/env python3
"""Prepare three MiniMax H3 two-reference-image ComfyUI workflows without spending credits."""

from __future__ import annotations

import argparse
import copy
import json
import re
import shutil
import sys
from pathlib import Path


SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_DIR / "assets/workflows/api_minimax_h3_r2v_two_images.json"
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp"}


def fail(message: str) -> None:
    raise SystemExit(f"錯誤：{message}")


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"找不到檔案：{path}")
    except json.JSONDecodeError as exc:
        fail(f"JSON 格式錯誤：{path}（{exc}）")


def validate_spec(spec: dict) -> tuple[list[Path], list[dict]]:
    refs = spec.get("reference_images")
    clips = spec.get("clips")
    if not isinstance(refs, list) or len(refs) != 2:
        fail("reference_images 必須剛好有兩張圖片")
    if not isinstance(clips, list) or len(clips) != 3:
        fail("clips 必須剛好有三段")

    ref_paths = []
    for raw_path in refs:
        path = Path(raw_path).expanduser().resolve()
        if not path.is_file():
            fail(f"參考圖不存在或不是檔案：{path}")
        if path.suffix.lower() not in IMAGE_SUFFIXES:
            fail(f"不支援的參考圖格式：{path.suffix}")
        ref_paths.append(path)

    for index, clip in enumerate(clips, start=1):
        if not isinstance(clip, dict) or not str(clip.get("prompt", "")).strip():
            fail(f"第 {index} 段缺少 prompt")
    return ref_paths, clips


def safe_prefix(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", value).strip("_")
    return cleaned or "h3_batch"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    spec_path = args.spec.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        fail(f"輸出資料夾不是空的，為避免重複任務不會覆寫：{output_dir}")

    spec = load_json(spec_path)
    ref_paths, clips = validate_spec(spec)
    duration = int(spec.get("duration", 10))
    if not 5 <= duration <= 15:
        fail("duration 必須介於 5 到 15 秒")
    resolution = str(spec.get("resolution", "768P"))
    if resolution not in {"768P", "1080P"}:
        fail("resolution 只接受 768P 或 1080P")
    ratio = str(spec.get("ratio", "adaptive"))
    seed_start = int(spec.get("seed_start", 42))
    prefix = safe_prefix(str(spec.get("output_prefix", "h3_batch")))

    inputs_dir = output_dir / "inputs"
    workflows_dir = output_dir / "workflows"
    outputs_dir = output_dir / "outputs"
    inputs_dir.mkdir(parents=True, exist_ok=True)
    workflows_dir.mkdir(parents=True, exist_ok=True)
    outputs_dir.mkdir(parents=True, exist_ok=True)

    copied_names = []
    for index, source in enumerate(ref_paths, start=1):
        target = inputs_dir / f"reference_{index}{source.suffix.lower()}"
        shutil.copy2(source, target)
        copied_names.append(target.name)

    template = load_json(TEMPLATE)
    manifest_clips = []
    for index, clip in enumerate(clips, start=1):
        workflow = copy.deepcopy(template)
        load_nodes = sorted(
            (node for node in workflow["nodes"] if node.get("type") == "LoadImage"),
            key=lambda node: node["id"],
        )
        h3_nodes = [
            node for node in workflow["nodes"]
            if node.get("type") == "MinimaxHailuo03ReferenceNode"
        ]
        save_nodes = [node for node in workflow["nodes"] if node.get("type") == "SaveVideo"]
        if len(load_nodes) != 2 or len(h3_nodes) != 1 or len(save_nodes) != 1:
            fail("雙圖工作流程模板的節點結構不符合預期")

        for node, filename in zip(load_nodes, copied_names):
            node["widgets_values"][0] = filename
        h3 = h3_nodes[0]
        h3["widgets_values"][0] = "MiniMax H3"
        h3["widgets_values"][1] = str(clip["prompt"]).strip()
        h3["widgets_values"][2] = resolution
        h3["widgets_values"][3] = ratio
        h3["widgets_values"][4] = duration
        h3["widgets_values"][5] = int(clip.get("seed", seed_start + index - 1))
        save_nodes[0]["widgets_values"][0] = f"video/{prefix}/clip_{index:02d}"

        workflow_path = workflows_dir / f"clip-{index:02d}.json"
        workflow_path.write_text(
            json.dumps(workflow, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        manifest_clips.append(
            {
                "clip": index,
                "workflow": str(workflow_path),
                "status": "prepared",
                "prompt_id": None,
                "output_dir": str(outputs_dir / f"clip-{index:02d}"),
            }
        )

    manifest = {
        "schema": "comfy-h3-video-batch/1",
        "project_name": spec.get("project_name", "MiniMax H3 三段影片"),
        "reference_images": [str(inputs_dir / name) for name in copied_names],
        "duration_seconds_each": duration,
        "total_requested_seconds": duration * 3,
        "resolution": resolution,
        "ratio": ratio,
        "spend_status": "not_approved",
        "clips": manifest_clips,
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
