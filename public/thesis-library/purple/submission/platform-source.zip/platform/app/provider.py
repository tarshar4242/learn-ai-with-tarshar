"""紫區 LLM 供應端：只走 OpenAI REST（httpx），固定端點、固定模型、無隱性重試。

安全約定（2026-10-22 CC 實作）：
- 金鑰只從環境變數或專案根目錄 .env 讀 OPENAI_API_KEY；不印出、不寫入任何紀錄或例外訊息。
- 模型讀 LLM_MODEL；沒設就明確報錯，不自動換模型、不 mock。
- 呼叫次數用 SQLite 持久計數，先「預約」再呼叫（BEGIN IMMEDIATE 鎖住，多程序也不會超過上限）；
  呼叫失敗、未知錯誤一樣計數。這是「呼叫次數」上限，不是美元精算。
- 單次請求輸入字元上限 50k、輸出 max_completion_tokens 上限 1800。
- 測試可注入 transport（httpx.MockTransport）或整個 client，不必打真實 API。
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx

OPENAI_BASE_URL = "https://api.openai.com/v1"  # 固定端點，不讀環境變數覆寫
MAX_INPUT_CHARS = 50_000
MAX_OUTPUT_TOKENS = 1800
DEFAULT_CALL_LIMIT = 100
DEFAULT_TIMEOUT = 60.0


class ProviderError(Exception):
    """供應端錯誤。code 給程式判斷，訊息給人看（絕不含金鑰）。"""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def read_dotenv(path: Path) -> Dict[str, str]:
    """極簡 .env 解析（KEY=VALUE，忽略註解與空行），不依賴 python-dotenv。"""
    out: Dict[str, str] = {}
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return out
    for line in lines:
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        if s.startswith("export "):
            s = s[len("export "):]
        k, v = s.split("=", 1)
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        out[k.strip()] = v
    return out


def _setting(name: str, dotenv: Dict[str, str]) -> Optional[str]:
    v = os.environ.get(name)
    if v is None or v == "":
        v = dotenv.get(name)
    return v or None


class CallBudget:
    """持久呼叫配額。每次 LLM 呼叫前 reserve()，結束後 finish()。"""

    def __init__(self, db_path: Path, limit: int = DEFAULT_CALL_LIMIT):
        self.db_path = Path(db_path)
        self.limit = int(limit)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.execute(
                "CREATE TABLE IF NOT EXISTS llm_calls ("
                " id INTEGER PRIMARY KEY AUTOINCREMENT, created REAL NOT NULL, model TEXT NOT NULL,"
                " purpose TEXT, status TEXT NOT NULL, input_chars INTEGER, max_output_tokens INTEGER,"
                " prompt_tokens INTEGER, completion_tokens INTEGER, total_tokens INTEGER,"
                " error_code TEXT, finished REAL)"
            )

    def _conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(str(self.db_path), timeout=30, isolation_level=None)
        return c

    def used(self) -> int:
        c = self._conn()
        try:
            return int(c.execute("SELECT COUNT(*) FROM llm_calls").fetchone()[0])
        finally:
            c.close()

    def reserve(self, model: str, purpose: str, input_chars: int, max_output_tokens: int) -> int:
        c = self._conn()
        try:
            c.execute("BEGIN IMMEDIATE")  # 寫鎖：多程序同時預約也只會有一個看到最後一格
            n = int(c.execute("SELECT COUNT(*) FROM llm_calls").fetchone()[0])
            if n >= self.limit:
                c.execute("ROLLBACK")
                raise ProviderError("budget_exceeded",
                                    f"LLM 呼叫次數已達上限 {self.limit} 次（持久計數），本次不呼叫。")
            cur = c.execute(
                "INSERT INTO llm_calls (created, model, purpose, status, input_chars, max_output_tokens)"
                " VALUES (?, ?, ?, 'reserved', ?, ?)",
                (time.time(), model, purpose, int(input_chars), int(max_output_tokens)),
            )
            rid = int(cur.lastrowid)
            c.execute("COMMIT")
            return rid
        except ProviderError:
            raise
        except Exception:
            try:
                c.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            c.close()

    def finish(self, rid: int, status: str, usage: Optional[Dict[str, Any]] = None,
               error_code: Optional[str] = None) -> None:
        u = usage or {}
        c = self._conn()
        try:
            c.execute(
                "UPDATE llm_calls SET status=?, prompt_tokens=?, completion_tokens=?, total_tokens=?,"
                " error_code=?, finished=? WHERE id=?",
                (status, u.get("prompt_tokens"), u.get("completion_tokens"), u.get("total_tokens"),
                 error_code, time.time(), rid),
            )
        finally:
            c.close()


class OpenAIProvider:
    """OpenAI Chat Completions（REST）。可注入 transport 方便測試。"""

    name = "openai"

    def __init__(self, root: Path, *, api_key: Optional[str] = None, model: Optional[str] = None,
                 budget: Optional[CallBudget] = None, transport: Optional[httpx.BaseTransport] = None,
                 timeout: float = DEFAULT_TIMEOUT):
        root = Path(root)
        dotenv = read_dotenv(root / ".env")
        self._api_key = api_key if api_key is not None else _setting("OPENAI_API_KEY", dotenv)
        self.model = model if model is not None else _setting("LLM_MODEL", dotenv)
        if budget is None:
            db = _setting("LLM_BUDGET_DB", dotenv) or str(root / "data" / "runtime" / "llm_budget.sqlite3")
            limit = int(_setting("LLM_CALL_LIMIT", dotenv) or DEFAULT_CALL_LIMIT)
            budget = CallBudget(Path(db), limit)
        self.budget = budget
        self._transport = transport
        self._timeout = timeout
        self._model_checked: Optional[bool] = None

    # ---- 狀態（不連網、不含金鑰）----
    @property
    def configured(self) -> bool:
        return bool(self._api_key) and bool(self.model)

    def status(self) -> Dict[str, Any]:
        return {
            "provider": self.name, "endpoint": OPENAI_BASE_URL, "model": self.model,
            "api_key_present": bool(self._api_key), "model_checked": self._model_checked,
            "calls_used": self.budget.used(), "call_limit": self.budget.limit,
            "budget_unit": "calls（呼叫次數上限，非美元精算）",
            "max_input_chars": MAX_INPUT_CHARS, "max_output_tokens": MAX_OUTPUT_TOKENS,
        }

    def _require_config(self) -> None:
        if not self._api_key:
            raise ProviderError("no_api_key", "未設定 OPENAI_API_KEY，B 組無法呼叫語言模型（不會用假回答代替）。")
        if not self.model:
            raise ProviderError("no_model", "未設定 LLM_MODEL，B 組不會自動挑模型。")

    def _client(self) -> httpx.Client:
        headers = {"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"}
        kw: Dict[str, Any] = {"base_url": OPENAI_BASE_URL, "headers": headers,
                              "timeout": self._timeout, "follow_redirects": False}
        kw["transport"] = self._transport if self._transport is not None else httpx.HTTPTransport(retries=0)
        return httpx.Client(**kw)

    def check_model(self) -> bool:
        """GET /models/{model} 確認模型可用（不計入 LLM 配額，因為不產生 token）。"""
        self._require_config()
        try:
            with self._client() as c:
                r = c.get(f"/models/{self.model}")
        except httpx.HTTPError as e:
            raise ProviderError("network_error", f"連不上 OpenAI（{type(e).__name__}）。") from None
        if r.status_code == 200:
            self._model_checked = True
            return True
        self._model_checked = False
        if r.status_code in (401, 403):
            raise ProviderError("auth_error", f"OpenAI 拒絕金鑰（HTTP {r.status_code}）。")
        if r.status_code == 404:
            raise ProviderError("model_unavailable", f"模型 {self.model} 在此帳號不可用，不會自動換模型。")
        raise ProviderError("http_error", f"查詢模型失敗（HTTP {r.status_code}）。")

    def chat_json(self, messages: List[Dict[str, str]], *, purpose: str,
                  max_output_tokens: int = 800) -> Dict[str, Any]:
        """送出一次 Chat Completion，要求 JSON 物件。回傳 {data, raw_text, usage, model}。"""
        self._require_config()
        if self._model_checked is None:
            self.check_model()
        elif self._model_checked is False:
            raise ProviderError("model_unavailable", f"模型 {self.model} 先前確認不可用。")
        input_chars = sum(len(m.get("content", "")) for m in messages)
        if input_chars > MAX_INPUT_CHARS:
            raise ProviderError("input_too_large", f"輸入 {input_chars} 字元超過上限 {MAX_INPUT_CHARS}，未呼叫。")
        mot = max(1, min(int(max_output_tokens), MAX_OUTPUT_TOKENS))
        rid = self.budget.reserve(self.model, purpose, input_chars, mot)
        body = {"model": self.model, "messages": messages, "response_format": {"type": "json_object"},
                "max_completion_tokens": mot, "temperature": 0}
        if str(self.model).startswith("gpt-5.4"):
            body["reasoning_effort"] = "none"
        status, usage, err = "error", None, "unknown_error"
        try:
            try:
                with self._client() as c:
                    r = c.post("/chat/completions", json=body)
            except httpx.HTTPError as e:
                err = "network_error"
                raise ProviderError("network_error", f"呼叫 OpenAI 失敗（{type(e).__name__}）。") from None
            if r.status_code != 200:
                err = {401: "auth_error", 403: "auth_error", 404: "model_unavailable",
                       429: "rate_limited"}.get(r.status_code, "http_error")
                raise ProviderError(err, f"OpenAI 回應 HTTP {r.status_code}（未重試）。")
            try:
                payload = r.json()
                choice = payload["choices"][0]
                raw_text = choice["message"].get("content") or ""
                usage = payload.get("usage") or {}
                usage = {k: usage.get(k) for k in ("prompt_tokens", "completion_tokens", "total_tokens")}
                finish = choice.get("finish_reason")
                used_model = payload.get("model")
            except (ValueError, KeyError, IndexError, TypeError):
                err = "bad_response"
                raise ProviderError("bad_response", "OpenAI 回應格式無法解析。") from None
            if finish == "length":
                err = "truncated"
                raise ProviderError("truncated", "模型輸出被截斷（達輸出上限），不採用。")
            try:
                data = json.loads(raw_text)
                if not isinstance(data, dict):
                    raise ValueError
            except ValueError:
                err = "bad_json"
                raise ProviderError("bad_json", "模型未回傳合法 JSON 物件。") from None
            status, err = "ok", None
            return {"data": data, "raw_text": raw_text, "usage": usage, "model": used_model or self.model,
                    "finish_reason": finish, "call_id": rid}
        finally:
            self.budget.finish(rid, status, usage, err)
