import assert from 'node:assert/strict';
import {makeWalkNetwork,makeTour,sampleTour,WALK_Y} from '../static/island/walk-network.js';
import fs from 'node:fs';
import {islandPosition,ISLAND_RADIUS,PATH_RADIUS,PATH_WIDTH,ISLAND_SPACING} from '../static/island/world-layout.js';
const data=JSON.parse(fs.readFileSync(new URL('../static/island/data.json',import.meta.url)));
const islands=data.islands.map(i=>({...i,...islandPosition(i.axial)}));
const network=makeWalkNetwork(islands),tour=makeTour(network,islands,data.avatar.route);assert.equal(network.nodes.length,60);
const visited=new Set();let bridgeSamples=0;for(let d=0;d<tour.length;d+=.025){const p=sampleTour(network,tour,d),q=sampleTour(network,tour,d+.025);visited.add(p.islandId);assert(Math.hypot(p.x-q.x,p.z-q.z)<=.02501);assert(p.y>=WALK_Y&&p.y<=WALK_Y+.10001);if(p.kind==='bridge')bridgeSamples++;}
assert.equal(visited.size,5);assert(bridgeSamples>0);const a=sampleTour(network,tour,0),b=sampleTour(network,tour,tour.length);assert.deepEqual([a.x,a.y,a.z],[b.x,b.y,b.z]);
console.log(JSON.stringify({nodes:60,bridges:network.edges.filter(e=>e.kind==='bridge').length,tourLength:tour.length,visited:[...visited],bridgeSamples,continuousLoop:true},null,2));

assert(PATH_RADIUS+PATH_WIDTH/2<ISLAND_RADIUS);assert(ISLAND_SPACING>ISLAND_RADIUS);

// Every destination is reachable from inside a path or bridge, without a snap.
const {makeRoute,sampleRoute,nearestBoothNode}=await import('../static/island/walk-network.js');
let destinationChecks=0;
for(const distance of [0,.43,tour.length*.27,tour.length*.68,tour.length-.1]){
 const start=sampleTour(network,tour,distance);
 for(let goal=0;goal<network.nodes.length;goal++){
  const route=makeRoute(network,start,goal),first=sampleRoute(network,route,0),last=sampleRoute(network,route,route.length+20);
  assert(Math.hypot(first.x-start.x,first.y-start.y,first.z-start.z)<1e-7,'No start teleport');
  assert(Math.hypot(last.x-network.nodes[goal].x,last.z-network.nodes[goal].z)<1e-7,'Exact clamped endpoint');
  for(let d=0;d<route.length;d+=.07){const p=sampleRoute(network,route,d),q=sampleRoute(network,route,d+.07);assert(Math.hypot(p.x-q.x,p.z-q.z)<=.07001);assert(p.y>=WALK_Y-1e-8&&p.y<=WALK_Y+.10001);}
  // Retarget midway: a new shortest path starts at the exact old position.
  const halfway=sampleRoute(network,route,route.length*.4),redirect=makeRoute(network,halfway,(goal+17)%network.nodes.length),restarted=sampleRoute(network,redirect,0);
  assert(Math.hypot(halfway.x-restarted.x,halfway.y-restarted.y,halfway.z-restarted.z)<1e-7);
  destinationChecks++;
 }
}
for(const island of islands){const node=nearestBoothNode(network,{...island,islandId:island.id});assert.equal(network.nodes[node].islandId,island.id);}
const sameNode={...network.nodes[0],from:0,to:0,t:0,kind:'path'};
assert.equal(makeRoute(network,sameNode,0).length,0);
assert(Number.isFinite(sampleRoute(network,makeRoute(network,sameNode,0),0).x));
console.log(JSON.stringify({destinationChecks,retargeting:true,noTeleport:true,endpointsClamp:true}));
