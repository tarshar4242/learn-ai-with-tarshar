#!/usr/bin/env python3
"""E2 reproducible preliminary metadata, not a human legal-validity certification.

Does not mutate corpus.json. Applies document-specific, evidence-backed findings;
unknown applicability remains unknown. Announcement and announced target differ.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
STATUSES = ('有效', '停止適用', '前提法條已刪除', '版本待查')
CHECK_DATE = '2026-10-26'


def annotate(doc: dict, findings: dict) -> dict:
    is_fint = doc['id'].startswith('FINT-')
    text = doc.get('text', '')
    compact = re.sub(r'\s+', '', text)
    flags = []
    if is_fint:
        flags.append('summary_only_not_full_interpretation')
        if 'recordno=' in doc.get('url', ''):
            flags.append('search_result_position_url')
        if '停止適用' in compact:
            flags.append('announces_other_interpretations_cessation')
        if '兩性工作平等法' in compact:
            flags.append('historical_law_name')
        if any(s in compact for s in ('基本工資', '津貼', '補助')):
            flags.append('benefit_or_wage_version_sensitive')
        if '性別工作平等法' in compact or '兩性工作平等法' in compact:
            flags.append('gender_law_version_sensitive')
        if any(s in compact for s in ('職業災害勞工保護法', '勞工安全衛生法')):
            flags.append('historical_statute_name_check_required')
    kind = doc.get('type', '')
    if kind == '指引':
        level = '官方指引／手冊；不得等同法律或法規命令；版本與出處仍待核對'
    elif kind == '問答':
        level = '官方FAQ說明；不得代替法規原文；更新日期與適用條件仍待核對'
    elif is_fint:
        level = '行政函釋要旨索引；未收全文；不是法律條文本身'
    else:
        level = '法規條文快照；尚未逐條核定版本及施行日期'
    record = {
        'id': doc['id'], 'status': '版本待查', 'effective_from': None,
        'superseded_by': None, 'validity_as_of': CHECK_DATE,
        'validity_review': 'AI逐筆初篩，非人工法律效力核定',
        'validity_review_note': '未完成全文、後續修法及停止適用鏈的逐筆查核；不得把未發現問題解讀為有效。',
        'validity_source_url': doc.get('url', ''),
        'validity_evidence': [], 'validity_flags': flags,
        'authority_level': level,
        'source_document_no': doc.get('no', ''),
        'source_document_date': doc.get('date', ''),
    }
    override = findings.get(doc['id'], {})
    extra_flags = override.get('validity_flags', [])
    record.update({k: v for k, v in override.items() if k != 'validity_flags'})
    record['validity_flags'] = sorted(set(flags + extra_flags))
    assert record['status'] in STATUSES
    return record


def build(corpus_path: Path, evidence_path: Path) -> dict:
    raw = corpus_path.read_bytes()
    corpus = json.loads(raw)
    evidence = json.loads(evidence_path.read_text())
    docs = corpus['docs']
    if len({d['id'] for d in docs}) != len(docs):
        raise ValueError('Duplicate document ids')
    findings = evidence['findings']
    unknown_ids = set(findings) - {d['id'] for d in docs}
    if unknown_ids:
        raise ValueError(f'Findings for absent ids: {unknown_ids}')
    rows = [annotate(d, findings) for d in docs]
    for row in rows:
        for source_id in row['validity_evidence']:
            if source_id not in evidence['sources']:
                raise ValueError(f'Missing source {source_id}')
    # Linking is exact document-number comparison, never mere keyword matching.
    for row in rows:
        for target in row.get('announced_targets', []):
            target['matched_corpus_ids'] = [
                d['id'] for d in docs
                if re.sub(r'\s+', '', d.get('no', '')) == re.sub(r'\s+', '', target['document_no'])
            ]
    return {
        'schema': 'validity-preliminary-v1', 'as_of': CHECK_DATE,
        'source_corpus_sha256': hashlib.sha256(raw).hexdigest(),
        'evidence_sha256': hashlib.sha256(evidence_path.read_bytes()).hexdigest(),
        'review_level': 'AI逐筆初篩＋列明來源的局部事實核對；未完成人工核定',
        'field_semantics': {
            'effective_from': '該文件本身生效日期；未知為null，不能用發文日或前提法條刪除日代填',
            'superseded_by': '已確認取代該文件的文件；未知為null，前提法條刪除不是替代函釋',
            'status_effective_from': '特定效力警示所依據法律變動的生效日期，與文件生效日期不同',
            'announced_targets': '公告所停止適用的其他文件；不等於公告本身停止適用',
            '版本待查': '尚未核定現行適用性，不代表有效，也不表示已失效',
        },
        'counts': {'documents': len(rows), 'interpretations': sum(d['id'].startswith('FINT-') for d in rows),
                   'status': {s: sum(d['status'] == s for d in rows) for s in STATUSES},
                   'interpretation_status': {s: sum(d['id'].startswith('FINT-') and d['status'] == s for d in rows) for s in STATUSES},
                   'human_verified': 0},
        'documents': rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', type=Path, default=ROOT / 'data/corpus.json')
    parser.add_argument('--evidence', type=Path, default=ROOT / 'data/validity/verified-findings.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'data/validity/document-metadata.json')
    args = parser.parse_args()
    result = build(args.corpus, args.evidence)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    fields = ['id', 'source_document_no', 'source_document_date', 'status', 'effective_from',
              'superseded_by', 'validity_review_note', 'validity_flags', 'validity_evidence']
    with args.output.with_name('interpretation-review.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in result['documents']:
            if row['id'].startswith('FINT-'):
                writer.writerow({key: '; '.join(row[key]) if isinstance(row[key], list)
                                 else row.get(key) for key in fields})
    print(json.dumps(result['counts'], ensure_ascii=False))

if __name__ == '__main__':
    main()
