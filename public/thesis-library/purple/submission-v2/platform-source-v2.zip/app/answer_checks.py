"""可重算的字面警示；不是法律推論或語意蘊含判定。

僅用於回答檢查，不修改使用者查詢、語料或檢索演算法。
有相同 token 仍可能指不同對象；沒有相同 token 也可能是正確推論。
"""
import re
from decimal import Decimal

DIGITS = dict(zip("零一二三四五六七八九", range(10)))
DIGITS["〇"] = 0
DIGITS["兩"] = 2
SMALL = {"十": 10, "百": 100, "千": 1000}
LARGE = {"萬": 10000, "億": 100000000}
NUMBER = r"(?:[0-9]+(?:,[0-9]{3})*(?:\.[0-9]+)?|[零〇一二兩三四五六七八九十百千萬億]+)"
QUANTITY = re.compile(
    r"(?<![0-9零〇一二兩三四五六七八九十百千萬億.,])(?P<pre>不得超過|未超過|不超過|不少於|不多於|不低於|不高於|未滿|不滿|未達|超過|至少|至多|不足|不到|少於|多於|未逾|不逾|逾|滿)?\s*"
    r"(?P<number>" + NUMBER + r")\s*"
    r"(?P<unit>個月|小時|分鐘|工作日|日|天|歲|年|月|週|元|人|次|倍|%|％)"
    r"\s*(?P<post>以上|以下|以內|以前|以後|之前|之後|前|後|內)?"
)
# Avoid the most common non-modal 得 (取得／獲得／所得／心得).
MODAL = re.compile(r"不得|不應(?:當|該)?|不可(?:以)?|應(?:當|該)?|(?<![取獲所心值])得(?!知|到|失)|可(?:以)?(?!能|愛|靠)")


def number_value(text):
    """Parse integer Chinese numerals and Arabic decimals; keep unknown forms literal."""
    text = text.replace(",", "")
    if re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", text):
        return format(Decimal(text).normalize(), "f") if "." in text else str(int(text))
    if all(c in DIGITS for c in text):
        return str(int("".join(str(DIGITS[c]) for c in text)))
    total = section = current = 0
    for c in text:
        if c in DIGITS:
            current = DIGITS[c]
        elif c in SMALL:
            section += (current or 1) * SMALL[c]
            current = 0
        elif c in LARGE:
            section += current
            if c == "億":
                total = (total + section) * LARGE[c]
            else:
                total += section * LARGE[c]
            section = current = 0
        else:
            return text
    return str(total + section + current)


def quantity_tokens(text):
    return [{"raw": m.group(0).strip(),
             "key": [m.group("pre") or "", number_value(m.group("number")),
                     m.group("unit"), m.group("post") or ""]}
            for m in QUANTITY.finditer(text)]


def modal_tokens(text):
    return list(dict.fromkeys(m.group(0)[:2] if m.group(0).startswith("不") else m.group(0)[0]
                              for m in MODAL.finditer(text)))


def boundary_mismatches(text, sources):
    """Every answer token must occur in at least one cited source; warn only."""
    source_keys = {tuple(t["key"]) for s in sources for t in quantity_tokens(s)}
    source_modals = {t for s in sources for t in modal_tokens(s)}
    out = [{"kind": "quantity_boundary", **t} for t in quantity_tokens(text)
           if tuple(t["key"]) not in source_keys]
    out.extend({"kind": "modal", "raw": t} for t in modal_tokens(text) if t not in source_modals)
    return out
