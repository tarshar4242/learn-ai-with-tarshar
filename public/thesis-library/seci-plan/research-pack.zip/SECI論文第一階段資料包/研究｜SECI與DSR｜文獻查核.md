# 研究｜SECI與DSR｜文獻查核

查核日：2026-11-14。版本：V0.2 討論稿，未經 TAR／指導教授核定。角色：知識管理與設計科學文獻查核 AI；不是受邀真人專家的審查意見。

已完整閱讀兩份 V0.1 附件文字。保留「自主完成、不依賴職場提供人員或機敏資料、路線 B 優先探索、路線 A 保留而不混入」的決策脈絡。本稿只提出研究與引用建議，不決定題目、正式樣本或開發。

## 一、先看結論與狀態

| 分類 | 查核結論與建議 |
|---|---|
| 已決議 | 本階段只規劃；以外化為焦點，不宣稱驗證完整 SECI；檢索、多人知識庫、商業化不進 MVP。這是附件與本次指示的邊界，並不表示教授已核定路線 B。 |
| 待確認 | 題目宜暫稱「經驗知識外化」；若堅持「隱性知識」，須說明如何辨識原本未明說的判斷線索及如何驗證，不能把任一整理後文字都稱隱性知識。正式主結果、比較條件、真實非機敏經驗的內容評分授權，交 TAR 與教授決定。 |
| 風險 | 已有直接相關 AI 訪談轉文件研究，因此「做出聊天工具」或「首次使用 AI 外化」不足作貢獻。標準案例若已提供關鍵線索，受測者主要在重組顯性文字；沒有新手使用測驗，不可說已提升知識傳承。 |
| 可延後 | 完整 SECI 循環、長期知識移轉、企業組織績效、語意檢索。這些需另一層證據，不因文獻提到就加入本研究。 |

上述可行性判斷是依下列文獻與附件做的研究設計推論，並非原作者對本論文的背書。

## 二、查核範圍與層級

本次為定向原典查核，不冒稱系統性文獻回顧。搜尋涵蓋 SECI／externalization、DSR／DSRM、tacit knowledge＋LLM／guided interview，以及「隱性知識、外顯化、SECI、標準作業程序」。使用出版社、AIS、arXiv 作者稿、作者出版清單、臺灣大學典藏與正式期刊頁。未以部落格、AI 摘要或搜尋排名作研究證據。

層級：**F**＝已取得全文並檢閱與本題相關的方法／結果／限制，不表示逐句精讀；**A**＝正式來源摘要與書目核對；**B**＝僅書目核對，方法細節仍須補原文。標示「全文可取得」與「已讀全文」分開。搜尋引擎對年份的自動顯示不作依據。

## 三、文獻矩陣

| 編號／作者年／正式題名 | DOI／可回查來源與層級 | 本研究可使用之處 | 不可由此宣稱 |
|---|---|---|---|
| E01 Nonaka, I. (1994). *A Dynamic Theory of Organizational Knowledge Creation*. Organization Science, 5(1), 14–37. | [INFORMS，10.1287/orsc.5.1.14](https://pubsonline.informs.org/doi/abs/10.1287/orsc.5.1.14)；A | 隱性與顯性知識互動、四種轉換的理論起點；外化作設計視角。 | 這篇不是本工具的成效量表，也沒有驗證生成式 AI。 |
| E02 Nonaka, I., & Takeuchi, H. (1995). *The Knowledge-Creating Company: How Japanese Companies Create the Dynamics of Innovation*. Oxford University Press. | [OUP，10.1093/oso/9780195092691.001.0001](https://doi.org/10.1093/oso/9780195092691.001.0001)；A；[第 3 章](https://doi.org/10.1093/oso/9780195092691.003.0003)為後續優先精讀 | 組織知識創造與由隱性到顯性的案例／概念脈絡。 | 個人完成一張知識卡不等於組織已經完成知識創造循環；書名相同的 1991 HBR 文章不是這本書。 |
| E03 Nonaka, I., Toyama, R., & Konno, N. (2000). *SECI, Ba and Leadership: a Unified Model of Dynamic Knowledge Creation*. Long Range Planning, 33(1), 5–34. | [Elsevier，10.1016/S0024-6301(99)00115-6](https://www.sciencedirect.com/science/article/pii/S0024630199001156)；A（含章節片段） | SECI、共同情境 ba、知識資產三者的關係；提醒外化依賴脈絡與互動。 | 不能把聊天室直接等同完整 ba，或因有四段畫面就聲稱驗證 SECI。 |
| E04 Hevner, A. R., March, S. T., Park, J., & Ram, S. (2004). *Design Science in Information Systems Research*. MIS Quarterly, 28(1). | [期刊 DOI：10.2307/25148625](https://doi.org/10.2307/25148625)；[AIS](https://aisel.aisnet.org/misq/vol28/iss1/10/)；A | 設計產物須對應問題並評估其效用；論文包含腳本、規準、原型及證據。 | 軟體能跑或使用者喜歡，不能單獨證明研究貢獻；DSR 不是免除有效評估的理由。 |
| E05 Peffers, K., Tuunanen, T., Rothenberger, M. A., & Chatterjee, S. (2007). *A Design Science Research Methodology for Information Systems Research*. JMIS, 24(3), 45–77. | [出版社，10.2753/MIS0742-1222240302](https://doi.org/10.2753/MIS0742-1222240302)；[大學收藏原版全文](https://zhang.ist.psu.edu/teaching/504/readings/Peffers.pdf)；F | 六活動：辨識問題、定義目標、設計開發、展示、評估、溝通；可迭代。 | 不能以做完六個步驟取代比較實驗與成效證據；2007／08 是跨年冬季期刊，不是兩篇研究。 |
| E06 Klein, G. A., Calderwood, R., & MacGregor, D. (1989). *Critical decision method for eliciting knowledge*. IEEE Transactions on Systems, Man, and Cybernetics, 19(3), 462–472. | [DOI：10.1109/21.31053](https://doi.org/10.1109/21.31053)；[作者出版清單](https://www.gary-klein.com/pub-list-1970-1995)；B，IEEE 頁受驗證限制 | 作關鍵事件訪談方法的原典入口；具體腳本細節須補原文或下列 ACTA 來源。 | 不可把自行改寫的五問腳本稱為已驗證 CDM，也不能說 AI 已具專家訪談能力。 |
| E07 Militello, L. G., & Hutton, R. J. B. (1998). *Applied cognitive task analysis (ACTA): a practitioner's toolkit for understanding cognitive task demands*. Ergonomics, 41(11), 1618–1641. | [PubMed 摘要／DOI：10.1080/001401398186108](https://pubmed.ncbi.nlm.nih.gov/9819578/)；[MIT 教學全文](https://web.mit.edu/16.459/www/Militello98.pdf)可取得；A | 任務概觀、知識盤點與情境訪談，可用來把「你如何做」追問為「看見什麼、如何判斷、哪裡容易出錯」。 | 原文評估的是人的訪談方法；不能直接轉成 AI 腳本效度證明。 |
| E08 Alavi, M., Leidner, D. E., & Mousavi, R. (2024). *A Knowledge Management Perspective of Generative Artificial Intelligence*. JAIS, 25(1), 1–12. | [AIS，10.17705/1jais.00859](https://aisel.aisnet.org/jais/vol25/iss1/15/)；A；編輯論文 | 區分創造、儲存、移轉、應用；討論 AI 與人類洞見、敏感資訊及過度依賴。 | 是概念性論述，不是「AI 外化一定有效」的實驗結果。 |
| E09 Singh, H., Shi, Y., & Van Toorn, C. (2024). *Generative AI-powered knowledge management in education: A dual perspective of design and use*. ACIS 2024 Proceedings, 134. | [AIS 正式論文頁](https://aisel.aisnet.org/acis2024/134/)；A，未確認 DOI | 澳洲教育平台個案，將 GenAI 與動態知識創造連結，可對照理論映射方式。 | 教育公司個案不能直接推論本研究受測者的外化分數或效果量。 |
| E10 Zuin, G., Mastelini, S., Loures, T., & Veloso, A. (2025). *Leveraging Large Language Models for Tacit Knowledge Discovery in Organizational Contexts*. | [作者稿 arXiv:2507.03811](https://arxiv.org/abs/2507.03811)；A；頁面記載獲 IJCNN 2025 接受 | 以代理互動還原分散資訊；864 次合成組織模擬可參考已知資訊的回收率測法。 | 94.9% 回收率來自模擬，不能當真人隱性知識訪談成效，更不能拿作本研究預期效果。 |
| E11 Roudiere, S., & Lento, B. (2026). *From Tacit Knowledge to Structured Documents: A Framework for Knowledge Elicitation*. ECKM 2026, 27(2). | [正式頁，10.34190/eckm.27.2.4875](https://papers.academic-conferences.org/index.php/eckm/article/view/4875)；[全文](https://papers.academic-conferences.org/index.php/eckm/article/download/4875/4580)；F | ASK 引導訪談、摘要、缺件檢查；12 名員工試行，與 191 份既有文件比較；可參考逐段本人核對與防重複追問。 | 不是同條件隨機對照。品質主要使用同型 LLM 評分，歷史文件與當次產出可比性有限；94.3 分鐘不宜移植成本案時間預測。 |
| E12 Cho, M., Funk, R. J., Gupta, A., & Yang, M. (2026). *Large Language Models Can Explain Experts Better Than Experts Themselves*. arXiv v2，2026-10-21 修訂。 | [10.48550/arXiv.2608.07488](https://arxiv.org/abs/2608.07488)；[全文](https://arxiv.org/html/2608.07488v2)；F；預印本，未核實正式期刊接受 | 以實際數學教學對話萃取，再讓新手執行任務；提供「文件品質」與「使用後表現」分開驗證的實例。 | 不能概括所有外化方法均優於專家；不同條件結果不同，改善亦依評分構面而異；短期教學反應不等於長期傳承。 |
| C01 周宣安（2016）。《建立企業標準作業程序中有關流程知識外顯化與隱性知識分享之系統》。國立中央大學資訊管理學系碩士論文。 | [中大典藏 handle:987654321/72089](https://ir.lib.ncu.edu.tw/handle/987654321/72089)；A，正式典藏搜尋索引已核摘要，直接開啟逾時 | K2SOP 以 SECI 為基礎，記錄執行經驗、導引及回饋；是臺灣資管領域直接相關先例。 | 摘要主張不能當嚴格因果效果；未閱完整評估章前不引用樣本或成效數字。亦非 GenAI 研究。 |
| C02 胡郁珮（2016）。〈取徑於 SECI 知識轉換模式實踐美感教育之初探－以視覺藝術教學為例〉。《教育研究學報》，50(2)，47–72。 | [臺南大學期刊全文，10.3966/199044282016105002003](https://cedu.nutn.edu.tw/journal/50b3.pdf)；F | 中文清楚區分默會／外顯與四種轉換；可參考由理論映射教學活動的論證。 | 屬理論與教學實例論述，不能作 AI 因果成效或本量表驗證；教學場域不可直接代表企業。 |

書目提醒：Peffers 採出版社建議年份 **2007**，原版標 Winter 2007–8、版權 2008；2014 是現平台上線日期。Hevner 常見原版頁數為 75–105，現出版社頁標 75–106；提交前以學校取得的原版與引用匯出再核對，本稿暫不固定該筆頁碼。這些差異不影響方法內容，但不應默默混用。

## 四、如何把理論用到可測量的設計

以下是本案建議，尚非已驗證量表。

| 理論／方法的角色 | 最小落實 | 可收的證據與界線 |
|---|---|---|
| SECI 外化：說明為何把經驗表述出來 | 受測者回想自己實際處理過的非機敏事件；從線索、判斷、行動到例外逐步表達 | 檢查經驗者是否補出先前未說明的判斷理由；只說「新增資訊」，不把每一項新增字句都認定是隱性知識 |
| ACTA／CDM：提供怎麼問的程序參考 | 固定主問＋有界追問：何處需要判斷、當時看到什麼、為何不選另一作法、新手容易漏掉什麼、哪種情境不適用 | 記錄腳本版本、問題目的與觸發條件；改編程序需自行試測與內容審查 |
| DSR：組織研究貢獻 | 問題→設計原則→原型／腳本→可重複評估→修訂紀錄 | 可用量化比較作評估；不因使用 DSR 就省略研究問題或測量效度 |
| DSRM：安排研究流程 | 先定目標與評分，再展示、評估、溝通 | 本輪做到規劃；展示能運作與評估能改善是兩件事 |

**SECI 不能直接當量表。** 四種知識轉換是概念分類，不能把 S、E、C、I 各寫幾題便宣稱完成量化。此題應使用「外化產出評分規準」，標示研究者自編；每分需有可觀察定義、正反例、評分者訓練與一致性檢查。滿意度測的是感受；欄位涵蓋度測的是結構；兩者都不能單獨取代內容正確性。

## 五、三個最重要的效度風險

1. **標準案例重寫不是個人隱性知識外化。** 若案例已寫出線索與正解，量到的較接近顯性資訊重組／摘要。它適合系統自測、建立正確答案與評分規準；若作唯一正式實驗，題目與結論就應限「經驗資訊結構化」。若要保留外化主張，需本人實際經驗或實作後回溯，但真實經驗的正確性也不能只由外部評分者猜測。
2. **完整的套裝流程有效，不等於已找出有效原因。** 「自由敘述」對「AI＋固定結構＋追問」同時改了多個因素。最小研究可保留附件的整體比較，但結論應寫「整套引導流程的差異」；若要單獨歸因 AI，須有相同欄位與提問的非 AI 對照，或增加其他條件。增加條件會提高樣本與工時，先交教授選擇。
3. **能讀、正確與能教會是三種結果。** 沒有新手拿卡片解新問題或實作的獨立測驗，就只能談可理解性／預期可用性，不能聲稱「知識傳承有效」。為守住最小範圍，建議本輪明列傳承成效為可延後，而非悄悄增加另一批新手。

E11 顯示相近方案已存在，也暴露重複追問、幻覺與 LLM 自評的侷限。因此本研究較可辯護的貢獻，是繁中可重複引導設計、來源可核對的產出規準、最小留存部署與公平的探索性比較；「繁中」或「隱私」本身仍須有具體設計與測試，不能只作標籤。

## 六、待 TAR／教授確認與下一步

- 是否保留「隱性」字樣，以及願意蒐集哪一種經同意的內容證據；原始對話不留存時，評分者究竟依據什麼判斷忠實性，須先解開。
- 將主要結果固定為一項（例如有來源支持的外化品質總分），其他時間、完成率、負擔列次要結果；本稿不決定樣本數。
- 補取得 E01、E02 第 3 章、E04、E06 原文與 C01 評估章；正式寫作前逐一核頁碼及研究限制。不得把本次 A／B 層級來源改寫成「全文精讀」。
- 將 E11 列最接近研究，逐項比較研究對象、提問流程、對照、評分來源與限制；保留正向、負向及不顯著結果，避免以搜尋不到某題目便宣稱研究缺口。
- 搜尋出現標示 2027 年 1 月「in press」的 KIT 論文；本輪未作已發表實證依據。正式計畫與論文提交前再更新檢索。

交班：已完成原典與近年研究矩陣、兩筆臺灣中文來源、理論到測量的界線及三項主要效度風險；未完成項為受限原文精讀、評分規準實證驗證與教授核定。僅供第一階段審查整合，未開發、未招募。
