"""Build the current festival overview from the same DATA as the park.
Run --check before export; run --word with python-docx to refresh editable files.
PDFs are rendered from Word and visually reviewed before publishing.
"""
from pathlib import Path
import argparse, json, html, hashlib
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'static/island-plan'
DATA=ROOT/'static/island/data.json'
INTRO='Tarshar 的研究同樂會是一座連續草地園區，有五個展區與十五個研究攤位。可自由探索，也可讓 Tarshar 沿步道帶路；研究內容提供工作稿與來源入口。'
FEATURES=[('分身帶路','開啟 Tarshar 帶路，選攤位後沿路抵達。途中可直接閱讀、直接抵達或停止；也能回到自由探索。'),('逐層閱讀','點展區，再選攤位，查看研究說明、狀態及原資料入口。節目單與搜尋提供快速閱讀方式。'),('園遊會場景','連續草地、摩天輪、帳篷、氣球與步道；支援旋轉、縮放、平移、滿視窗與日夜切換。'),('虛構研究夥伴','松果、栗子、阿栗、米露是虛構夥伴，不影射真人。Tarshar 公仔造型與 Logo 沿用定稿。')]
STATUS='目前是模擬試玩實驗場。研究內容是有日期的固定版本快照，更新資料並重新發布後才反映新進度，尚未自動即時同步。散步、日夜與研究路線是展示互動，不代表 AI 正在執行研究。'
FUTURE='進度燈旗、里程碑慶祝、相同文件的檢索比較體驗、細項知識關聯與研究時間軸仍屬後續規劃，不能列為已完成。'
MODEL='Codex 與茜茜依實際工作分工協作；3D 展示本身不呼叫語言模型。A/B 實驗是另一個需原有私人網路的服務，展示頁不改動其模型、語料或評分。尚無比較結果可宣稱哪個模型最適合。'
def contents(data):
 zones=data['islands']; names='、'.join(z['title'] for z in zones)
 md='# 研究同樂會 現行設計與功能說明\n\n更新：2026-10-26。展區與攤位名稱由程式 data.json 產生。舊版五島提案已由本說明取代，既有網址保留。\n\n'+INTRO+'\n\n## 五個展區與十五個攤位\n\n'
 for z in zones:
  md+=f"### {z['title']}\n\n{len(z['items'])} 個攤位："+'、'.join(i['title'] for i in z['items'])+'。\n\n'+z['summary']+'\n\n'
 md+='## 現在可以怎麼玩\n\n'+'\n\n'.join(t+'：'+v for t,v in FEATURES)+'\n\n## 資料更新與完成範圍\n\n'+STATUS+'\n\n'+FUTURE+'\n\n## 模型與協作\n\n'+MODEL+'\n\n公開入口：https://tarshar4242.github.io/learn-ai-with-tarshar/thesis-library/purple/island/\n'
 prompt='# 研究同樂會 現行維護指令\n\n請先盤點既有研究同樂會，再進行漸進式改進。不要重建成舊五島版。\n\n1. 正式名稱為 Tarshar 的研究同樂會；空間單位叫展區與攤位。內部 island、compass 等 ID 可保留以維持路網與連結，不作為顯示名稱。\n2. 展區與攤位以 static/island/data.json 為唯一資料來源。目前展區：'+names+'。目前共有十五個攤位，名稱與排序不得另外手抄。\n3. 保留連續草地園遊會、五區十五攤、既有資料入口、Tarshar 定稿模型及 Logo。四位虛構夥伴為松果、栗子、阿栗、米露。\n4. 保留 Tarshar 帶路、自由探索、節目單、搜尋、縮放平移、滿視窗、日夜、路線、散步及減少動態。\n5. '+STATUS+'\n6. '+FUTURE+'\n7. '+MODEL+'\n8. 更新 DATA 後執行 scripts/build_festival_docs.py；用 --word 更新 Word，重新轉 PDF 並逐頁檢查。執行 --check 確認網頁與 Markdown 未落後，再將 static/island 與 static/island-plan 匯出至主網站紫區相同目錄。更新 Drive 原檔與共同大腦，完成正式網址回讀。\n'
 cards=''.join(f'<article class="card" style="--c:{z["color"]}"><p class="eyebrow">展區 {n:02d} · {len(z["items"])} 個攤位</p><h3>{html.escape(z["title"])}</h3><p>{html.escape(z["summary"])}</p><ul>'+''.join('<li>'+html.escape(i['title'])+'</li>' for i in z['items'])+'</ul></article>' for n,z in enumerate(zones,1))
 features=''.join('<article><h3>'+t+'</h3><p>'+v+'</p></article>' for t,v in FEATURES)
 page='''<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>研究同樂會｜現行設計與功能說明</title><style>*{box-sizing:border-box}body{margin:0;background:#faf6ef;color:#302c36;font-family:-apple-system,BlinkMacSystemFont,"PingFang TC","Microsoft JhengHei",sans-serif;line-height:1.85}main{max-width:1040px;margin:auto;padding:28px 22px 64px}h1{font-size:clamp(30px,5vw,46px);line-height:1.3}h2{margin-top:38px}.note{padding:20px;background:#ece5f6;border-radius:18px}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}.card{padding:22px;border-radius:18px;background:white;border-top:5px solid var(--c);box-shadow:0 6px 20px #37244308}.card h3{margin:0}.eyebrow,.small{font-size:14px;color:#65596d}.links{display:flex;gap:10px;flex-wrap:wrap;margin:22px 0}.links a{padding:12px 16px;border-radius:12px;background:#59436a;color:white;text-decoration:none;min-height:44px}a{color:#59436a;overflow-wrap:anywhere}a:focus-visible,summary:focus-visible{outline:3px solid #db6a41;outline-offset:3px}summary{cursor:pointer;padding:16px;font-weight:700}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:white;padding:20px;border-radius:16px;font:16px/1.8 -apple-system,sans-serif}li{margin:5px 0}@media(max-width:650px){.grid{grid-template-columns:1fr}}</style></head><body><main><a href="../">← 回紫區研究入口</a><p class="eyebrow">2026.10.26 · 現行版本說明</p><h1>Tarshar 的研究同樂會</h1><p>'''+INTRO+'''</p><div class="note"><b>五個展區、十五個研究攤位</b><br>本頁與程式使用同一份展區及攤位資料。早期「五座島」提案已由現行同樂會設計取代。</div><nav class="links"><a href="../island/">進入研究同樂會</a><a href="../island/guide/guide.pdf">操作說明 PDF</a><a href="proposal.pdf">現行設計 PDF</a><a href="proposal.docx">現行設計 Word</a></nav><h2>五個展區怎麼逛</h2><section class="grid">'''+cards+'''</section><h2>現在可以怎麼玩</h2><section class="grid">'''+features+'''</section><h2>資料怎麼更新</h2><p>'''+STATUS+'''</p><h2>接下來的規劃</h2><p>'''+FUTURE+'''</p><h2>模型與協作</h2><p>'''+MODEL+'''</p><details id="prompt"><summary>現行維護指令</summary><pre>'''+html.escape(prompt)+'''</pre><a href="island-prompt.md">下載維護指令</a></details><details><summary>早期協作歷史</summary><p>2026-10-23 的五島提案與當時分工屬歷史，不能當作目前功能說明。</p><a href="collaboration.md">閱讀早期協作紀錄</a></details><p class="small">展區與攤位來源：研究同樂會 data.json。研究來源快照日期與介面版本分開記錄；本頁更新不代表研究進度已推進。</p></main></body></html>'''
 return {'proposal.md':md,'island-prompt.md':prompt,'index.html':page}
def word(data):
 from docx import Document
 from docx.shared import Inches,Pt,RGBColor
 from docx.oxml.ns import qn
 d=Document();sec=d.sections[0];sec.page_width=Inches(8.27);sec.page_height=Inches(11.69);sec.top_margin=sec.bottom_margin=Inches(.7);sec.left_margin=sec.right_margin=Inches(.75)
 for name,size in [('Normal',11),('Title',24),('Heading 1',17),('Heading 2',13)]:
  st=d.styles[name];st.font.name='Noto Sans CJK TC';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0);st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Noto Sans CJK TC');st.paragraph_format.space_after=Pt(7);st.paragraph_format.line_spacing=1.15
 
 for st in d.styles:
  for border in list(st.element.iter(qn('w:pBdr'))):border.getparent().remove(border)
 d.add_paragraph('研究同樂會 現行設計與功能說明','Title');d.add_paragraph('2026年10月26日更新');d.add_paragraph(INTRO)
 d.add_paragraph('五個展區與十五個攤位','Heading 1')
 for z in data['islands']:
  d.add_paragraph(z['title']+'  '+str(len(z['items']))+' 個攤位','Heading 2');d.add_paragraph('、'.join(i['title'] for i in z['items']));d.add_paragraph(z['summary'])
 d.add_page_break();d.add_paragraph('探索方式與資料更新','Title')
 for t,v in FEATURES:d.add_paragraph(t,'Heading 2');d.add_paragraph(v)
 for t,v in [('資料更新方式',STATUS),('後續規劃',FUTURE),('模型與協作',MODEL)]:d.add_paragraph(t,'Heading 2');d.add_paragraph(v)
 d.add_paragraph('完整操作說明與資料入口請由研究同樂會網站開啟。早期五島名稱已停用；既有網址與程式 ID 保留，避免舊連結失效。')
 d.save(OUT/'proposal.docx')
def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--word',action='store_true');a=p.parse_args();data=json.loads(DATA.read_text());out=contents(data)
 if a.check:
  for f,s in out.items():assert (OUT/f).read_text()==s,f+' differs from current DATA; rebuild docs'
  print('Current overview matches DATA:',len(data['islands']),'zones,',sum(len(z['items']) for z in data['islands']),'booths');return
 OUT.mkdir(exist_ok=True)
 for f,s in out.items():(OUT/f).write_text(s)
 if a.word:word(data)
 print('Generated',OUT)
if __name__=='__main__':main()
