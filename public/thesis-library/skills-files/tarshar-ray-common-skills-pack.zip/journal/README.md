# 學習日記 Skill by 雷小蒙

來源：老師 private repo `skills/learning-journal/`
版本：1.0.0
作者：Raymond Hou
授權：CC BY-NC-SA 4.0，個人學習使用

安裝到本專案：

```text
000_Agent/skills/journal/
```

觸發方式：

- `寫日記`
- `今天結束了`
- `學習紀錄`
- `journal`
- `記錄一下今天`

日記儲存位置：

```text
journals/YYYY-MM-DD.md
```
