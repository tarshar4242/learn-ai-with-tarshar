# 發佈清單：把 edm-NNN 接進系列、推上線、驗證

> 電子報寫好、Tarshar 過目 OK 之後照這份逐項做。倉庫：`~/kt-site/kt-sweet-journey`（發佈分支 `main`）。
> 這個 repo 常有多個 session 共寫，**push 前一定 `git pull --rebase`**。

## 要動到的檔案（共 5 個，缺一不同步）

| 檔案 | 改什麼 |
| :-- | :-- |
| `edm-NNN.html` | 新增（電子報本體） |
| `edm-NNN-img/` | 新增（成品圖，若有） |
| `index.html` | 「主題式電子報」系列 `#view-edm` 最前面加一張卡片 |
| `lessons.html` | 同上（`index.html` 的鏡像，內容要一致） |
| `sitemap.html` | `const DATA` 裡 `"key": "edm"` 的 `items` 陣列，最前面加一筆 |
| `docs/SITEMAP.md` | 「共 N 期」數字 +1；「六、SERIES 07」下加一則條目 |

> 註：`index.html` 與 `lessons.html` 目前是同一份鏡像，系列卡片兩邊都要加同一張。
> 系列頁上的「收錄 N 期」是 JS 依 `.course:not(.soon)` 數量自動算的，加了卡片就會自己變，不用手改數字。

## 系列卡片範本（貼進 index.html 與 lessons.html 的 `<!-- 電子報卡片：新一期往上加 -->` 註解下方、既有最新一張之前）

```html
      <div class="course" style="--c:var(--rose)">
        <div class="top"></div>
        <div class="body">
          <span class="ep">電子報 NNN · YYYY.MM.DD</span>
          <h2>{{主標題}}</h2>
          <p class="desc">{{兩三句摘要：做了什麼、關鍵原理、有沒有成品}}</p>
          <div class="tags"><span>🎴 {{關鍵字}}</span><span>🗂️ {{關鍵字}}</span><span>🗝️ {{關鍵字}}</span></div>
          <div class="date">📅 YYYY.MM.DD · {{分類}}</div>
        </div>
        <div class="links" style="grid-template-columns:1fr">
          <a href="edm-NNN.html">📮 開啟這一期</a>
        </div>
      </div>
```

## sitemap.html DATA 範本（加在 edm items 陣列最前面）

```json
{"code": "NNN", "title": "{{主標題}}", "links": [{"label": "📮 開啟這一期", "url": "https://tarshar4242.github.io/kt-sweet-journey/edm-NNN.html"}]},
```

## git 流程

```bash
cd ~/kt-site/kt-sweet-journey
git add edm-NNN.html edm-NNN-img/ index.html lessons.html sitemap.html docs/SITEMAP.md
git -c user.name="tarshar4242" -c user.email="a0956859863@gmail.com" \
  commit -m "電子報 NNN：{{一句話主題}}"
git pull --rebase origin main
git push origin main
```

## 驗證（實抓，抓到才算完成）

```bash
B="https://tarshar4242.github.io/kt-sweet-journey"
# 1) 本體頁
for i in 1 2 3 4 5 6; do c=$(curl -s -o /dev/null -w "%{http_code}" "$B/edm-NNN.html"); echo "edm-NNN: $c"; [ "$c" = 200 ] && break; sleep 15; done
# 2) 每一張圖片
for f in edm-NNN-img/*.jpg; do n=$(basename "$f"); echo "$n: $(curl -s -o /dev/null -w '%{http_code}' "$B/edm-NNN-img/$n")"; done
# 3) 系列頁已含新卡片
curl -s "$B/lessons.html" | grep -o "edm-NNN.html" | head -1
```
- 頁面 200、**每張圖都 200**、系列頁抓得到 `edm-NNN.html` → 完成。
- 抓到 404 是 Pages 還在建置，等 15 秒重試，最多約 6 次；仍舊版就跟 Tarshar 說「已推送，Pages 生效中，約 1–2 分鐘後可見」。

## 回報格式

```
✅ 電子報 NNN 上線
🌐 這一期：https://tarshar4242.github.io/kt-sweet-journey/edm-NNN.html
🌐 系列頁：https://tarshar4242.github.io/kt-sweet-journey/lessons.html#edm
你現在可以怎麼用：手機點連結就能看；要發電子報／貼 FB 可直接用這個網址。
```
