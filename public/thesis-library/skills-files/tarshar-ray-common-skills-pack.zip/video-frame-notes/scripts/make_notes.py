#!/usr/bin/env python3
"""影片逐幀筆記產生器：關鍵畫面 + 字卡 OCR + 逐字稿，輸出 HTML / Markdown / 純文字。

用法：
    python3 make_notes.py <影片資料夾> [--out 輸出資料夾] [--only 01,03]

每一階段都逐支落檔，中斷後重跑會自動跳過已完成的部分。
"""
import argparse, glob, html, json, os, re, shutil, subprocess, sys, time, urllib.parse
from PIL import Image, ImageStat

# ── 這些預設值是實測調出來的，改之前先看 SKILL.md 的「為什麼是這些數字」 ──
SCENE_TH = 0.20        # 場景切換靈敏度
OFFSETS = [1.2, 2.2, 0.6]   # 切換點之後往後幾秒抓（避開淡入淡出）
MIN_GAP = 2.5          # 兩張保留圖至少相隔幾秒
SLIDE_FLAT = 0.38      # 平坦度大於此值視為字卡／投影片
TH_SLIDE = 6           # 字卡之間去重門檻（嚴格：不同字卡都要留）
TH_TALKER = 14         # 講者鏡頭之間去重門檻（寬鬆：長得像就丟）
MODEL = "mlx-community/whisper-large-v3-turbo"
AUDIO_ONLY_MAX = 2     # 保留畫面數 <= 此值視為語音單元
AUDIO_SEG = 120        # 語音單元每幾秒切一段

CJK = r"㐀-鿿豈-﫿　-〿＀-￯"
PUNC = {",": "，", "?": "？", "!": "！", ":": "：", ";": "；"}

# 語音辨識常聽錯的工具名，只列可確定的；不確定的一律不要加
FIX = [
    (r"Trap\s?GPT|SharePGPT|Shared\s?GPT|\bGBT\b", "ChatGPT"),
    (r"HetaBest|Hepta\s?Best|header\s?base", "Heptabase"),
    (r"Google\s+Gemman9|Gemman9|German9|Germen9", "Gemini"),
    (r"realize\s+reader|rewise\s+reader", "Readwise Reader"),
    (r"\bMe\s+Journey\b", "Midjourney"),
    (r"\bOpenEye\b", "OpenAI"),
]

try:
    from opencc import OpenCC
    _cc = OpenCC("s2tw")   # 只還原字形。不要用 s2twp，它會把「優化」改成「最佳化」
except ImportError:
    sys.exit("缺 opencc：python3 -m pip install --user opencc-python-reimplemented")


# ──────────────────────────── 共用 ────────────────────────────
def norm(t):
    """繁體字形還原 + 修可確定的工具名 + 半形標點轉全形"""
    t = _cc.convert(t)
    for pat, rep in FIX:
        t = re.sub(pat, rep, t, flags=re.I)
    out = []
    for i, ch in enumerate(t):
        if ch in PUNC:
            prev = t[i - 1] if i else ""
            nxt = t[i + 1] if i + 1 < len(t) else ""
            if re.match(f"[{CJK}]", prev) or re.match(f"[{CJK}]", nxt):
                out.append(PUNC[ch])
                continue
        out.append(ch)
    s = re.sub(r"[ \t]+", " ", "".join(out)).strip()
    return re.sub(f"(?<=[{CJK}]) (?=[{CJK}])", "", s)


def mmss(t):
    return f"{int(t)//60:02d}:{int(t)%60:02d}"


def hhmm(sec):
    m, s = divmod(int(sec), 60)
    return f"{m} 分 {s} 秒"


def clean_stem(stem):
    """'04 04. 怎麼培養…' -> '04 怎麼培養…'"""
    m = re.match(r"^(\d+)\s+\d+\.?\s*(.+)$", stem)
    return f"{m.group(1)} {m.group(2).strip()}" if m else stem


def duration(v):
    return float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", v], capture_output=True, text=True).stdout.strip())


# ──────────────────────── 階段一：逐字稿 ────────────────────────
def run_asr(videos, work, prompt):
    import mlx_whisper
    d = os.path.join(work, "asr")
    os.makedirs(d, exist_ok=True)
    for i, v in enumerate(videos, 1):
        stem = os.path.splitext(os.path.basename(v))[0]
        out = os.path.join(d, f"{stem}.json")
        if os.path.exists(out):
            print(f"  [{i}/{len(videos)}] 逐字稿已存在，跳過 {stem[:30]}", flush=True)
            continue
        wav = os.path.join(work, "_tmp.wav")
        subprocess.run(["ffmpeg", "-v", "error", "-i", v, "-vn", "-ac", "1",
                        "-ar", "16000", "-c:a", "pcm_s16le", wav, "-y"], check=True)
        t0 = time.time()
        r = mlx_whisper.transcribe(
            wav, path_or_hf_repo=MODEL, language="zh", initial_prompt=prompt,
            condition_on_previous_text=True,   # 關掉會沒有標點，整段黏成一串
            verbose=False)
        segs = [{"start": s["start"], "end": s["end"], "text": s["text"].strip()}
                for s in r["segments"] if s["text"].strip()]
        json.dump({"file": os.path.basename(v), "segments": segs},
                  open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        os.remove(wav)
        print(f"  [{i}/{len(videos)}] 逐字稿 {stem[:30]} — {len(segs)} 段 "
              f"（{time.time()-t0:.0f} 秒）", flush=True)


# ──────────────────────── 階段二：關鍵畫面 ────────────────────────
def dhash(img, size=8):
    g = img.convert("L").resize((size + 1, size), Image.LANCZOS)
    px, bits = list(g.getdata()), 0
    for r in range(size):
        row = px[r * (size + 1):(r + 1) * (size + 1)]
        for c in range(size):
            bits = (bits << 1) | (1 if row[c] < row[c + 1] else 0)
    return bits


def stats(img):
    """(平均亮度, 亮度標準差, 平坦度)"""
    st = ImageStat.Stat(img.convert("L"))
    small = img.convert("RGB").resize((80, 45))
    b = {}
    for p in small.getdata():
        k = (p[0] // 32, p[1] // 32, p[2] // 32)
        b[k] = b.get(k, 0) + 1
    return st.mean[0], st.stddev[0], max(b.values()) / (80 * 45)


def grab(video, t, dest):
    subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", video,
                    "-frames:v", "1", "-vf", "scale=1280:-2", "-q:v", "4",
                    dest, "-y"], check=True)
    return os.path.exists(dest) and os.path.getsize(dest) > 0


def run_frames(videos, work):
    base = os.path.join(work, "frames")
    os.makedirs(base, exist_ok=True)
    tmp = os.path.join(base, "_tmp.jpg")
    scenes_txt = os.path.join(base, "_scenes.txt")
    for i, v in enumerate(videos, 1):
        stem = os.path.splitext(os.path.basename(v))[0]
        manifest = os.path.join(base, f"{stem}.json")
        if os.path.exists(manifest):
            print(f"  [{i}/{len(videos)}] 畫面已存在，跳過 {stem[:30]}", flush=True)
            continue
        outdir = os.path.join(base, stem)
        shutil.rmtree(outdir, ignore_errors=True)
        os.makedirs(outdir, exist_ok=True)
        dur, t0 = duration(v), time.time()

        subprocess.run(["ffmpeg", "-v", "error", "-i", v, "-vf",
                        f"select='gt(scene,{SCENE_TH})',metadata=print:file={scenes_txt}",
                        "-an", "-f", "null", "-"], check=True)
        cuts = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", open(scenes_txt).read())]
        cuts = [2.0] + cuts + ([t for t in range(60, int(dur), 90)] if dur > 60 else [])
        cuts = sorted(set(round(c, 1) for c in cuts))

        kept, h_slide, h_talker, last_t = [], [], [], -99
        for c in cuts:
            if c - last_t < MIN_GAP:
                continue
            chosen = None
            for off in OFFSETS:
                t = c + off
                if t >= dur - 0.5 or not grab(v, t, tmp):
                    continue
                img = Image.open(tmp)
                mean, sd, flat = stats(img)
                if mean < 22 or sd < 12:      # 全黑或純色轉場，換下個偏移再試
                    continue
                chosen = (t, img.copy(), flat)
                break
            if not chosen:
                continue
            t, img, flat = chosen
            is_slide = flat >= SLIDE_FLAT
            h = dhash(img)
            pool, th = (h_slide, TH_SLIDE) if is_slide else (h_talker, TH_TALKER)
            if any(bin(h ^ k).count("1") <= th for k in pool):
                continue
            pool.append(h)
            last_t = t
            name = f"{len(kept)+1:03d}_{int(t)//60:02d}m{int(t)%60:02d}s.jpg"
            img.save(os.path.join(outdir, name), quality=88)
            kept.append({"t": round(t, 2), "img": name,
                         "kind": "slide" if is_slide else "talker"})

        json.dump({"file": os.path.basename(v), "duration": dur, "frames": kept},
                  open(manifest, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        ns = sum(1 for k in kept if k["kind"] == "slide")
        print(f"  [{i}/{len(videos)}] 畫面 {stem[:30]} — 保留 {len(kept)} 張"
              f"（字卡 {ns}／講者 {len(kept)-ns}）（{time.time()-t0:.0f} 秒）", flush=True)
    for f in (tmp, scenes_txt):
        if os.path.exists(f):
            os.remove(f)


# ──────────────────────── 階段三：OCR ────────────────────────
def ensure_ocr(skill_dir, work):
    """編譯 macOS Vision OCR（免安裝、免網路、繁中準確度好）"""
    src = os.path.join(skill_dir, "scripts", "ocr.swift")
    binp = os.path.join(work, "ocrbin")
    if os.path.exists(binp):
        return binp
    env = dict(os.environ, SWIFT_MODULE_CACHE=os.path.join(work, "swift-mc"))
    r = subprocess.run(["swiftc", "-O", src, "-o", binp], capture_output=True, text=True, env=env)
    if r.returncode:
        print("  OCR 編譯失敗，字卡文字會留白：", r.stderr[:300], flush=True)
        return None
    return binp


def ocr_all(binp, paths):
    if not binp or not paths:
        return {}
    out = ""
    for i in range(0, len(paths), 20):
        out += subprocess.run([binp] + paths[i:i + 20], capture_output=True, text=True).stdout
    res = {}
    for block in out.split("<<<FILE:")[1:]:
        head, _, body = block.partition(">>>\n")
        res[head.strip()] = body.strip()
    return res


# ──────────────────────── 階段四：合成 ────────────────────────
def paragraphs(segs):
    paras, buf, last_end = [], [], None
    for s in segs:
        if buf and (sum(len(x) for x in buf) > 170 or
                    (last_end is not None and s["start"] - last_end > 2.2)):
            paras.append("".join(buf))
            buf = []
        buf.append(norm(s["text"]))
        last_end = s["end"]
    if buf:
        paras.append("".join(buf))
    return [p for p in paras if p]


CSS = """:root{--bg:#fbfaf8;--fg:#23201c;--muted:#6f6a63;--line:#e6e1d9;--card:#fff;--accent:#c2410c}
@media(prefers-color-scheme:dark){:root{--bg:#16150f;--fg:#ece7de;--muted:#a39c90;--line:#332f27;--card:#1e1c15;--accent:#f59e5b}}
*{box-sizing:border-box}
body{margin:0;padding:1.5rem 1rem 5rem;background:var(--bg);color:var(--fg);
 font:16px/1.85 "Helvetica Neue","PingFang TC","Noto Sans TC",sans-serif;max-width:820px;margin-inline:auto}
h1{font-size:1.6rem;line-height:1.4;margin:0 0 .6rem}
h2{font-size:1.15rem;margin:2.4rem 0 .8rem;padding-bottom:.4rem;border-bottom:2px solid var(--line)}
h3{font-size:1rem;color:var(--accent);margin:0 0 .7rem;font-variant-numeric:tabular-nums}
p{margin:.55rem 0}
.meta,.note{color:var(--muted);font-size:.85rem;line-height:1.7}
.note{padding:.6rem .9rem;background:var(--card);border-left:3px solid var(--accent);border-radius:4px}
code{font-size:.85em;background:var(--card);padding:.1em .35em;border-radius:3px;word-break:break-all}
ul.idx{list-style:none;padding:0;margin:0;columns:2;column-gap:1.6rem}
@media(max-width:600px){ul.idx{columns:1}}
ul.idx li{margin:.25rem 0;font-size:.9rem;break-inside:avoid}
ul.idx a{color:var(--accent);text-decoration:none;font-variant-numeric:tabular-nums}
section{margin:0 0 2.6rem;padding-top:.8rem;border-top:1px solid var(--line)}
img{width:100%;height:auto;border-radius:6px;border:1px solid var(--line);display:block;margin:.3rem 0 .9rem}
.card{background:var(--card);border:1px solid var(--line);border-left:3px solid var(--accent);
 border-radius:5px;padding:.7rem 1rem;margin:.6rem 0 1rem}
.card p{margin:.15rem 0;font-size:.94rem}
.lbl{font-size:.75rem;letter-spacing:.12em;color:var(--muted);margin:.9rem 0 .2rem}
a{color:var(--accent)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.1rem}
.tile{display:flex;flex-direction:column;background:var(--card);border:1px solid var(--line);
 border-radius:9px;overflow:hidden;text-decoration:none;color:inherit}
.tile:hover{border-color:var(--accent)}
.thumb{aspect-ratio:16/9;background:var(--line);overflow:hidden}
.thumb img{width:100%;height:100%;object-fit:cover;margin:0;border:0;border-radius:0}
.tbody{padding:.8rem 1rem 1rem}
.no{font-size:.72rem;letter-spacing:.16em;color:var(--accent);font-weight:600}
.tile h3{font-size:.98rem;line-height:1.5;margin:.25rem 0 .5rem;color:inherit}
.stat{font-size:.78rem;color:var(--muted);font-variant-numeric:tabular-nums}"""


def shell(title, body):
    return (f'<!doctype html>\n<html lang="zh-Hant"><head><meta charset="utf-8">\n'
            f'<meta name="viewport" content="width=device-width,initial-scale=1">\n'
            f"<title>{title}</title>\n<style>\n{CSS}\n</style></head><body>\n{body}\n</body></html>")


def build(videos, work, dest, today, author):
    ocrbin = ensure_ocr(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), work)
    os.makedirs(dest, exist_ok=True)
    rows = []
    for v in videos:
        stem = os.path.splitext(os.path.basename(v))[0]
        asr = json.load(open(os.path.join(work, "asr", f"{stem}.json"), encoding="utf-8"))
        fr = json.load(open(os.path.join(work, "frames", f"{stem}.json"), encoding="utf-8"))
        segs, frames, dur = asr["segments"], fr["frames"], fr["duration"]

        nice = clean_stem(stem)
        outdir = os.path.join(dest, nice)
        imgdir = os.path.join(outdir, "frames")
        os.makedirs(imgdir, exist_ok=True)
        for f in glob.glob(os.path.join(imgdir, "*.jpg")):
            os.remove(f)
        for f in frames:
            shutil.copy(os.path.join(work, "frames", stem, f["img"]),
                        os.path.join(imgdir, f["img"]))
        ocr = ocr_all(ocrbin, [os.path.join(imgdir, f["img"]) for f in frames])
        for f in frames:
            f["ocr"] = ocr.get(os.path.join(imgdir, f["img"]), "")

        audio_only = len(frames) <= AUDIO_ONLY_MAX
        sections = []
        if audio_only:
            marks = list(range(0, int(dur), AUDIO_SEG))
            for j, t in enumerate(marks):
                end = marks[j + 1] if j + 1 < len(marks) else dur + 1
                sec = [s for s in segs if t <= s["start"] < end]
                if sec:
                    sections.append({"t": t, "frame": frames[0] if j == 0 and frames else None,
                                     "segs": sec})
        else:
            for j, f in enumerate(frames):
                start = f["t"] if j else 0
                end = frames[j + 1]["t"] if j + 1 < len(frames) else dur + 1
                sections.append({"t": f["t"], "frame": f,
                                 "segs": [s for s in segs if start <= s["start"] < end]})

        no, txt = (nice.split(" ", 1) + [""])[:2]
        n_slide = sum(1 for f in frames if f["kind"] == "slide")
        idx = []
        for f in frames:
            # 講者鏡頭的 OCR 只會讀到衣服或背景的字，不能當標題
            cap = "" if f["kind"] == "talker" else next(
                (l for l in f["ocr"].split("\n")
                 if len(l.strip()) > 1 and not re.fullmatch(r"[0-9\W_]+", l.strip())), "")
            idx.append((mmss(f["t"]), norm(cap)[:40]))

        md = [f"# {no}｜{txt}", "",
              f"> 影片長度 {hhmm(dur)}　關鍵畫面 {len(frames)} 張（字卡 {n_slide}）　逐字稿 {len(segs)} 段  ",
              f"> 原始影片：`{asr['file']}`　整理日期：{today}　整理：{author}  ",
              "> 逐字稿由本機語音辨識產生，人名與工具名可能聽錯，引用前請對照影片。  "]
        if audio_only:
            md.append("> **這是語音單元**，畫面全程固定，以下依時間分段。  ")
        md += ["", "## 畫面索引", ""]
        md += [f"- **{t}**　{c}" if c else f"- **{t}**　（講者鏡頭）" for t, c in idx]
        md += ["", "---", "", "## 逐幀筆記", ""]

        h = [f"<h1>{html.escape(no)}｜{html.escape(txt)}</h1>",
             f'<p class=meta>影片長度 {hhmm(dur)}　關鍵畫面 {len(frames)} 張（字卡 {n_slide}）　'
             f'逐字稿 {len(segs)} 段<br>原始影片：<code>{html.escape(asr["file"])}</code>　'
             f'整理日期：{today}　整理：{author}<br>'
             f'逐字稿由本機語音辨識產生，人名與工具名可能聽錯，引用前請對照影片。</p>']
        if audio_only:
            h.append("<p class=note>這是語音單元，畫面全程固定，以下依時間分段。</p>")
        h.append("<h2>畫面索引</h2><ul class=idx>")
        h += [f'<li><a href="#s{j}"><b>{t}</b></a> {html.escape(c) if c else "（講者鏡頭）"}</li>'
              for j, (t, c) in enumerate(idx, 1)]
        h.append("</ul><h2>逐幀筆記</h2>")

        for j, s in enumerate(sections, 1):
            f = s["frame"]
            md += [f"### {j}　{mmss(s['t'])}", ""]
            h.append(f'<section id="s{j}"><h3>{j}　{mmss(s["t"])}</h3>')
            if f:
                md += [f"![{mmss(f['t'])}](frames/{f['img']})", ""]
                h.append(f'<img src="frames/{html.escape(f["img"])}" loading="lazy" alt="">')
                if f["ocr"] and f["kind"] == "slide":
                    md += ["**畫面文字**", ""]
                    md += [f"> {norm(l.strip())}" for l in f["ocr"].split("\n") if l.strip()]
                    md.append("")
                    h.append("<div class=card><div class=lbl>畫面文字</div>" + "".join(
                        f"<p>{html.escape(norm(l.strip()))}</p>"
                        for l in f["ocr"].split("\n") if l.strip()) + "</div>")
            md += ["**口述內容**", ""]
            h.append("<div class=lbl>口述內容</div>")
            for p in paragraphs(s["segs"]):
                md += [p, ""]
                h.append(f"<p>{html.escape(p)}</p>")
            md.append("")
            h.append("</section>")

        open(os.path.join(outdir, "筆記.md"), "w", encoding="utf-8").write("\n".join(md))
        open(os.path.join(outdir, "筆記.html"), "w", encoding="utf-8").write(
            shell(html.escape(f"{no}｜{txt}"), "\n".join(h)))
        tx = [f"{no}｜{txt}", f"影片長度 {hhmm(dur)}　逐字稿 {len(segs)} 段", "=" * 50, ""]
        tx += [f"[{mmss(s['start'])}] {norm(s['text'])}" for s in segs]
        open(os.path.join(outdir, "逐字稿.txt"), "w", encoding="utf-8").write("\n".join(tx))

        rows.append({"no": no, "title": txt, "dir": nice, "dur": dur, "frames": len(frames),
                     "slides": n_slide, "segs": len(segs), "audio_only": audio_only,
                     "thumb": frames[0]["img"] if frames else ""})
        print(f"  筆記 {nice[:34]} — 畫面 {len(frames)}、逐字稿 {len(segs)} 段", flush=True)
    return rows


def build_index(rows, dest, today, author):
    q = urllib.parse.quote
    tot_d = sum(r["dur"] for r in rows)
    tiles = []
    for r in rows:
        tag = "語音單元" if r["audio_only"] else f"字卡 {r['slides']}"
        th = f'<img src="{q(r["dir"])}/frames/{q(r["thumb"])}" loading=lazy alt="">' if r["thumb"] else ""
        tiles.append(f'<a class=tile href="{q(r["dir"])}/筆記.html"><div class=thumb>{th}</div>'
                     f'<div class=tbody><div class=no>{html.escape(r["no"])}</div>'
                     f'<h3>{html.escape(r["title"])}</h3>'
                     f'<div class=stat>{int(r["dur"]//60)}:{int(r["dur"]%60):02d}　{tag}　'
                     f'逐字稿 {r["segs"]} 段</div></div></a>')
    body = (f"<h1>逐幀擷取筆記</h1><p class=meta>共 {len(rows)} 支影片　總長 {int(tot_d//60)} 分鐘　"
            f"關鍵畫面 {sum(r['frames'] for r in rows)} 張<br>整理日期：{today}　整理：{author}</p>"
            f'<div class=grid>{"".join(tiles)}</div>'
            f'<p class=note style="margin-top:2rem">每支資料夾裡有三個檔：<code>筆記.html</code> 圖文對照、'
            f'<code>筆記.md</code> 可丟 Obsidian、<code>逐字稿.txt</code> 純文字全文。<br>'
            f'逐字稿是本機語音辨識產生的，人名與工具名可能聽錯，引用前請對照影片。</p>')
    open(os.path.join(dest, "index.html"), "w", encoding="utf-8").write(shell("逐幀擷取筆記", body))

    md = ["# 逐幀擷取筆記", "",
          f"共 {len(rows)} 支影片，總長 {int(tot_d//60)} 分鐘。整理日期：{today}　整理：{author}", "",
          "**先開這個**：`index.html`（雙擊，用瀏覽器看）", "",
          "| # | 單元 | 長度 | 關鍵畫面 | 逐字稿 |", "|---|---|---|---|---|"]
    for r in rows:
        tag = "語音單元" if r["audio_only"] else f"{r['frames']} 張（字卡 {r['slides']}）"
        md.append(f"| {r['no']} | [{r['title']}]({q(r['dir'])}/筆記.md) | "
                  f"{int(r['dur']//60)}:{int(r['dur']%60):02d} | {tag} | {r['segs']} 段 |")
    md += ["", "逐字稿是本機語音辨識產生的，人名與工具名可能聽錯，引用前請對照影片。"]
    open(os.path.join(dest, "README.md"), "w", encoding="utf-8").write("\n".join(md))


def verify(dest, rows):
    """交付前自檢：檔案齊不齊、圖片連結斷沒斷"""
    bad = []
    for r in rows:
        d = os.path.join(dest, r["dir"])
        for f in ("筆記.html", "筆記.md", "逐字稿.txt"):
            if not os.path.exists(os.path.join(d, f)):
                bad.append(f"{r['dir']} 缺 {f}")
        h = open(os.path.join(d, "筆記.html"), encoding="utf-8").read()
        for s in re.findall(r'<img src="([^"]+)"', h):
            if not os.path.exists(os.path.join(d, html.unescape(s))):
                bad.append(f"{r['dir']} 圖片斷鏈 {s}")
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src", help="影片資料夾")
    ap.add_argument("--out", help="輸出資料夾（預設 <影片資料夾>/逐幀筆記）")
    ap.add_argument("--work", help="中繼檔資料夾（預設系統暫存）")
    ap.add_argument("--only", help="只處理檔名開頭符合的，逗號分隔，例 01,03")
    ap.add_argument("--author", default="知臨")
    ap.add_argument("--prompt", default="以下是繁體中文線上課程的口語內容。",
                    help="給語音辨識的提示，寫上課程常見專有名詞可大幅減少聽錯")
    a = ap.parse_args()

    videos = sorted(glob.glob(os.path.join(a.src, "*.mp4")) +
                    glob.glob(os.path.join(a.src, "*.mov")) +
                    glob.glob(os.path.join(a.src, "*.m4v")))
    if a.only:
        pre = tuple(x.strip() for x in a.only.split(","))
        videos = [v for v in videos if os.path.basename(v).startswith(pre)]
    if not videos:
        sys.exit(f"找不到影片：{a.src}")

    dest = a.out or os.path.join(a.src, "逐幀筆記")
    work = a.work or os.path.join(os.environ.get("TMPDIR", "/tmp"),
                                  "video-frame-notes",
                                  re.sub(r"\W+", "_", os.path.basename(a.src.rstrip("/"))))
    os.makedirs(work, exist_ok=True)
    today = time.strftime("%Y-%m-%d")

    print(f"共 {len(videos)} 支影片\n中繼檔：{work}\n輸出：{dest}\n")
    print("① 逐字稿", flush=True)
    run_asr(videos, work, a.prompt)
    print("② 關鍵畫面", flush=True)
    run_frames(videos, work)
    print("③ 合成筆記", flush=True)
    rows = build(videos, work, dest, today, a.author)
    build_index(rows, dest, today, a.author)
    print("④ 自檢", flush=True)
    bad = verify(dest, rows)
    print("  " + ("全部通過" if not bad else "有問題：\n  " + "\n  ".join(bad)), flush=True)
    print(f"\n完成 → {os.path.join(dest, 'index.html')}")


if __name__ == "__main__":
    main()
