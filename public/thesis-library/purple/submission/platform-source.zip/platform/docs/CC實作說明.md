> 本文件記錄 CC 第一輪實作。後續 Codex 整合已調整模型、候選合併、網址清單與防護；現行規格以 README、程式和「取材與修正紀錄」為準。

# CC 實作說明｜紫區引擎與 LLM 供應端

> 2026-10-22，CC（Claude）實作。範圍：`app/engine.py`、`app/provider.py`、`tests/test_engine.py`、`requirements.txt`、本檔。server／前端／凍結／部署由 Codex 負責。
> 開發測試不是正式論文結果。NotebookLM 只是體驗參照，不是第三組，也不宣稱複刻。

## 介面

| 方法 | 回傳重點 |
|---|---|
| `Engine(root)` | 讀 `root/data/corpus.json`（綠區 docs schema），記 `corpus_hash`（整檔 sha256） |
| `.literal(query, offset=0, limit=20)` | `query, total（命中文件數）, occurrences（全部出現次數）, offset, limit, has_more, hits[{id, law, no, title, type, text, url, matches[[s,e]], title_matches[[s,e]], count}]` |
| `.ask(query, history=[])` | `status: answered/clarify/insufficient/error, answer, points[{text, citations, refs}], citations[{id, law, no, title, type, text, url}], hits, rewritten, clarify_question, review_notice, warnings, provider, model, trace, error_code（error 時）` |
| `.document(id)` | 單筆文件或 `None` |
| `.status()` | 語料、A/B 設定、向量模型與快取、LLM 狀態（不含金鑰）、prompt 雜湊 |

測試注入：`Engine(root, llm=假LLM, encoder_factory=假編碼器, cache_dir=...)`；`OpenAIProvider(root, transport=httpx.MockTransport(...), budget=CallBudget(...))`。

## A 組：Ctrl+F

- 整段查詢＝一個連續原字串，`str.find` 不重疊由左至右計數（瀏覽器 Ctrl+F 的數法）。
- 空白、標點不拆；不 OR、不 BM25；**區分大小寫、不做全半形轉換**（嚴格原字串）。
- 比對欄位：標題（`law + " " + no`）與內文**各自比對、不跨欄拼接**；`matches` 是內文位移，`title_matches` 是標題位移。
- 只有空白或空字串回 `error`；查詢上限 500 字；`limit` 1–100。

## B 組：語意問答

1. 前文：只收 `role ∈ {user, assistant}` 的字串，取最後 6 輪（12 則），每則截 2000 字。
2. LLM 改寫（`rewrite`）：只可用使用者明說的條件，不得憑空補；含糊就回 `clarify`。改寫不可用時以原問題檢索並記 warning。
3. 本機向量：`BAAI/bge-base-zh-v1.5` revision `f03589ceff5aac7111bd60cfc7d497ca17ecac65`，`local_files_only`，查詢指令為 BGE 官方中文指令。文件文字＝`標題\n內文`。文件向量快取在 `data/cache/docvec_<key>.npy`，key 含模型、revision、指令、語料雜湊、編碼文字雜湊。top-k＝8。第一次建向量在 Mac mini 約 30 秒。
4. LLM 依證據回答（`answer`）：證據以 JSON 行包在 `<evidence>`，系統提示寫明資料內指令只當文字。
5. 程式驗證：每個要點的每個引用 id 都必須在**本輪證據**裡（語料有但不在 top-k 也不算）；任一引用無效或沒引用 → 整個要點移除；沒有剩下的要點 → `insufficient`，不會 `answered`。
6. 輸出網址：只放行語料內、`https`、網域 `law.moj.gov.tw` 的網址，其餘給 `null`；模型文字裡的網址一律刪除。
7. `review_notice`：引用有效只代表來源在本輪證據中，不代表支持該說法，需人工核對。

`trace` 保留：`corpus_hash, embed_model, embed_revision, provider, model, prompt_hashes（兩個系統提示＋兩次實際訊息）, history_messages, rewrite, retrieved[{id, score}], llm_calls[{purpose, model, usage, call_id}], usage_total, model_status, validation`。查詢日誌不在引擎寫，由 server 記。

## 供應端（OpenAI REST）

- 端點固定 `https://api.openai.com/v1`；`httpx.HTTPTransport(retries=0)`、不跟隨轉址、無隱性重試；不自動換模型。
- 讀 `OPENAI_API_KEY`、`LLM_MODEL`：先看環境變數，**環境變數為空字串會再讀 `.env`**。沒有金鑰或模型 → `error`，不 mock。
- 第一次呼叫前 `GET /models/{model}` 確認可用（不計配額）；404 → `model_unavailable`。
- `response_format: json_object`、`max_completion_tokens`（上限 1800）、`temperature 0`；輸出被截斷、非 JSON 一律報錯不採用。
- 配額：SQLite（預設 `data/runtime/llm_budget.sqlite3`，可用 `LLM_BUDGET_DB` 改；上限 `LLM_CALL_LIMIT` 預設 100）。`BEGIN IMMEDIATE` 先預約再呼叫，多程序不會超過；HTTP 錯誤、網路錯誤、未知例外都計數。單位是**呼叫次數，非美元精算**。單次輸入上限 50,000 字元（超過不呼叫、不計數）。
- 配額表只記模型、用途、狀態、字元數、token usage、錯誤碼；不含金鑰、不含提示全文。

## 測試

`.venv/bin/python -m pytest tests/test_engine.py -q` → 26 passed（全部假 LLM／假編碼器／MockTransport）。涵蓋：空白不拆、標點不拆、不 OR、全部出現次數＋標題、區分大小寫、分頁、空白查詢、未驗證網址、有效引用、偽造引用、語料有但非本輪證據、混合要點、無引用、證據不足、釐清、前文截斷與過濾、資料內指令、無金鑰（真供應端）、向量快取重用、請求格式與輸出上限、跨實例配額、錯誤計數與不重試、金鑰不外洩、輸入上限、模型 404、壞 JSON、截斷、.env 讀取。

另用真實語料＋本機 BGE 跑過冒煙：`literal("中高齡者")` 270 文件／477 次；`literal("勞工 保險")` 0（空白不拆）；向量檢索正常，768 維。

## 已知不足

- 冒煙時誤打了 **1 次真實 API**（rewrite，345＋46 tokens，gpt-4.1-mini，約新台幣 1 分）。原因：以為把 `OPENAI_API_KEY=` 設空就擋住，但空值會退回讀 `.env`，而 `.env` 已有金鑰。該次記在 `/tmp/cc_smoke_budget.sqlite3`，**沒有計入專案配額 DB**。同時確認 `gpt-4.1-mini` 模型可用。
- 「意圖條件不得憑空補」只靠提示詞約束，程式無法語意檢查改寫是否偷加條件；trace 有 `rewritten` 可人工抽查。
- 引用驗證只驗 id 存在於本輪證據，不驗內容是否支持說法（已用 `review_notice` 提示）。
- 向量快取與配額 DB 會寫入 `data/cache/`、`data/runtime/`，部署時請 Codex 確認這兩處可寫且不進版控。
- 尚未用真實 API 做端到端品質測試（依分工由 Codex 執行）。
