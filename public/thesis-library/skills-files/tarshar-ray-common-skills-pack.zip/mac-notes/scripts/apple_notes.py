#!/usr/bin/env python3
"""Safe CLI bridge to Apple Notes through its official scripting interface."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


JXA = r"""
function value(fn, fallback) {
  try {
    const result = fn();
    return result === undefined || result === null ? fallback : result;
  } catch (_) {
    return fallback;
  }
}

function isoDate(raw) {
  try {
    const date = new Date(raw);
    return Number.isNaN(date.getTime()) ? String(raw || "") : date.toISOString();
  } catch (_) {
    return String(raw || "");
  }
}

function noteMeta(note) {
  const folder = value(() => note.container(), null);
  return {
    id: value(() => note.id(), ""),
    title: value(() => note.name(), "(無標題)"),
    folder: folder ? value(() => folder.name(), "") : "",
    modified_at: isoDate(value(() => note.modificationDate(), "")),
    created_at: isoDate(value(() => note.creationDate(), "")),
    password_protected: Boolean(value(() => note.passwordProtected(), false)),
    shared: Boolean(value(() => note.shared(), false))
  };
}

function allNotes(notesApp) {
  return notesApp.notes().map(note => ({note: note, meta: noteMeta(note)}));
}

function sortRecent(items) {
  return items.sort((a, b) =>
    String(b.meta.modified_at).localeCompare(String(a.meta.modified_at))
  );
}

function plainText(item) {
  if (item.meta.password_protected) return "";
  return value(() => item.note.plaintext(), "");
}

function htmlEscape(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function run(argv) {
  const Notes = Application("Notes");
  Notes.includeStandardAdditions = true;
  const command = argv[0] || "status";
  const limit = Math.max(1, Math.min(200, Number(argv[2] || argv[1] || 20)));

  if (command === "status") {
    return JSON.stringify({
      ok: true,
      accounts: Notes.accounts.length,
      notes: Notes.notes.length
    });
  }

  const items = allNotes(Notes);

  if (command === "recent") {
    return JSON.stringify({
      ok: true,
      notes: sortRecent(items).slice(0, limit).map(item => item.meta)
    });
  }

  if (command === "search") {
    const query = String(argv[1] || "").trim().toLocaleLowerCase();
    if (!query) throw new Error("搜尋關鍵字不可為空");
    const matches = items.filter(item => {
      const title = String(item.meta.title).toLocaleLowerCase();
      const text = String(plainText(item)).toLocaleLowerCase();
      return title.includes(query) || text.includes(query);
    });
    return JSON.stringify({
      ok: true,
      query: argv[1],
      notes: sortRecent(matches).slice(0, limit).map(item => item.meta)
    });
  }

  if (command === "read") {
    const query = String(argv[1] || "").trim().toLocaleLowerCase();
    if (!query) throw new Error("筆記標題或 ID 不可為空");
    const exact = items.filter(item =>
      String(item.meta.id).toLocaleLowerCase() === query ||
      String(item.meta.title).toLocaleLowerCase() === query
    );
    const candidates = exact.length ? exact : items.filter(item =>
      String(item.meta.title).toLocaleLowerCase().includes(query)
    );
    if (candidates.length === 0) {
      return JSON.stringify({ok: false, error: "找不到符合的筆記", candidates: []});
    }
    if (candidates.length > 1) {
      return JSON.stringify({
        ok: false,
        error: "找到多則候選筆記，請用完整標題或 ID 指定",
        candidates: sortRecent(candidates).slice(0, 20).map(item => item.meta)
      });
    }
    const item = candidates[0];
    return JSON.stringify({
      ok: true,
      note: Object.assign({}, item.meta, {
        plaintext: item.meta.password_protected ? null : plainText(item)
      })
    });
  }

  if (command === "todos") {
    const unchecked = /^\s*(?:-\s*\[\s\]|☐|□|○|◯|⬜)\s*(.+?)\s*$/u;
    const labelled = /^\s*(?:待辦|未完成|todo)\s*[:：]\s*(.+?)\s*$/iu;
    const results = [];
    for (const item of sortRecent(items)) {
      if (results.length >= limit) break;
      if (item.meta.password_protected) continue;
      const tasks = [];
      for (const line of String(plainText(item)).split(/\r?\n|\u2028/)) {
        const match = line.match(unchecked) || line.match(labelled);
        if (match && match[1]) tasks.push(match[1].trim());
      }
      if (tasks.length) results.push(Object.assign({}, item.meta, {tasks: tasks}));
    }
    return JSON.stringify({
      ok: true,
      notes: results,
      limitation: "Apple 原生 Checklist 的勾選狀態不由 Notes AppleScript 介面提供；此結果只含可辨識的文字待辦標記。"
    });
  }

  if (command === "create") {
    const title = String(argv[1] || "").trim();
    const body = String(argv[2] || "").trim();
    const folderName = String(argv[3] || "").trim();
    if (!title) throw new Error("標題不可為空");
    let targetFolder = Notes.defaultAccount.defaultFolder();
    if (folderName) {
      const folders = Notes.folders.whose({name: folderName})();
      if (folders.length === 0) throw new Error("找不到資料夾：" + folderName);
      targetFolder = folders[0];
    }
    const html = "<div><strong>" + htmlEscape(title) + "</strong></div><div>" +
      htmlEscape(body).replace(/\n/g, "<br>") + "</div>";
    const created = Notes.Note({name: title, body: html});
    targetFolder.notes.push(created);
    return JSON.stringify({ok: true, note: noteMeta(created)});
  }

  throw new Error("不支援的指令：" + command);
}
"""


def run_jxa(arguments: list[str]) -> dict:
    command = ["osascript", "-l", "JavaScript", "-e", JXA, "--", *arguments]
    try:
        result = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
            timeout=45,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Notes 超過 45 秒沒有回應") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "未知錯誤").strip()
        if "-1743" in detail or "Not authorized" in detail:
            detail += (
                "\n請到「系統設定 → 隱私權與安全性 → 自動化」，"
                "允許目前使用的終端或 AI 應用程式控制「備忘錄」。"
            )
        raise RuntimeError(detail) from exc

    output = result.stdout.strip()
    if not output:
        raise RuntimeError("Notes 沒有回傳資料")
    return json.loads(output)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Apple 備忘錄 CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("status", help="檢查 Notes 連線與筆記數量")

    recent = subparsers.add_parser("recent", help="列出最近修改的筆記")
    recent.add_argument("--limit", type=int, default=5)

    search = subparsers.add_parser("search", help="搜尋標題與純文字內文")
    search.add_argument("query")
    search.add_argument("--limit", type=int, default=10)

    read = subparsers.add_parser("read", help="讀取一則指定筆記")
    read.add_argument("query", help="完整標題、部分標題或筆記 ID")

    todos = subparsers.add_parser("todos", help="盤點文字格式的未完成待辦")
    todos.add_argument("--limit", type=int, default=30)

    create = subparsers.add_parser("create", help="新增一則筆記（不提供刪除）")
    create.add_argument("title")
    create.add_argument("body")
    create.add_argument("--folder", default="")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    jxa_args = [args.command]
    if args.command == "recent":
        jxa_args += ["", str(args.limit)]
    elif args.command == "search":
        jxa_args += [args.query, str(args.limit)]
    elif args.command == "read":
        jxa_args += [args.query]
    elif args.command == "todos":
        jxa_args += ["", str(args.limit)]
    elif args.command == "create":
        jxa_args += [args.title, args.body, args.folder]

    try:
        data = run_jxa(jxa_args)
    except (RuntimeError, json.JSONDecodeError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 1

    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0 if data.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
