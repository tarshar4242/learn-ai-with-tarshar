#!/usr/bin/env python3
"""把 Notion「公開分享」頁面整批抓成 Markdown（不需要登入、不需要 API 金鑰）。

用法：
    # 先看這頁裡有哪些資料庫
    python3 dl_notion_public.py --out ./文稿 --list 1ece6e22663280bea497daaff36dc637

    # 抓整個資料庫
    python3 dl_notion_public.py --out ./文稿 --collection <cid> --view <vid>

    # 抓單一頁（可重複 --page）
    python3 dl_notion_public.py --out ./文稿 --page 1ece6e22663280bea497daaff36dc637

注意：
- 只對「已公開分享」的頁面有效；私人頁面會回 401/404，那時要走登入的瀏覽器。
- Notion 會限流（HTTP 429），本腳本每頁間隔 3 秒並自動退避重試。
- 逐頁落檔，中斷後重跑會跳過已完成的檔案。
- 表單頁抓不到內文（內容是表單元件），要另外用瀏覽器讀。
- 付費內容只存本機，不要外流或公開部署。
"""
import argparse, json, os, re, time, urllib.request, urllib.error

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36")


def api(path, payload):
    req = urllib.request.Request(
        f"https://www.notion.so/api/v3/{path}", data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "User-Agent": UA})
    for attempt in range(6):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < 5:
                time.sleep(30 + attempt * 20)
                continue
            raise
        except Exception:
            if attempt == 5:
                raise
            time.sleep(5 + attempt * 5)


def dashed(pid):
    p = pid.replace("-", "")
    return f"{p[:8]}-{p[8:12]}-{p[12:16]}-{p[16:20]}-{p[20:]}"


def val_of(rec):
    return rec.get("value", {}).get("value") or rec.get("value", {}) or {}


def rt(props, key="title"):
    v = (props or {}).get(key)
    if not v:
        return ""
    out = []
    for seg in v:
        s = seg[0] if seg else ""
        if s == "‣":
            continue
        href = None
        for f in (seg[1] if len(seg) > 1 and seg[1] else []):
            if f and f[0] == "a":
                href = f[1]
        out.append(f"[{s}]({href})" if href else s)   # 保留超連結，否則工具連結全掉
    return "".join(out).strip()


def load_page(pid):
    blocks, cursor, seen = {}, {"stack": []}, 0
    for chunk in range(12):
        d = api("loadPageChunk", {"pageId": dashed(pid), "limit": 100, "cursor": cursor,
                                  "chunkNumber": chunk, "verticalColumns": False})
        blocks.update(d.get("recordMap", {}).get("block", {}))
        cursor = d.get("cursor", {"stack": []})
        if not cursor.get("stack") or len(blocks) == seen:
            break
        seen = len(blocks)
        time.sleep(0.25)
    return blocks


def to_md(pid, blocks):
    root = val_of(blocks.get(dashed(pid), {}))
    lines, num = [], 0

    def walk(bid, depth=0):
        nonlocal num
        v = val_of(blocks.get(bid, {}))
        if not v:
            return
        t, p = v.get("type"), v.get("properties", {})
        txt, pad = rt(p), "  " * depth
        if t == "header":
            lines.append(f"\n## {txt}\n")
        elif t == "sub_header":
            lines.append(f"\n### {txt}\n")
        elif t == "sub_sub_header":
            lines.append(f"\n#### {txt}\n")
        elif t == "text":
            lines.append(txt + "\n" if txt else "")
        elif t == "bulleted_list":
            lines.append(f"{pad}- {txt}")
        elif t == "numbered_list":
            num += 1
            lines.append(f"{pad}{num}. {txt}")
        elif t == "quote":
            lines.append(f"> {txt}\n")
        elif t == "callout":
            lines.append(f"> **{txt}**\n")
        elif t == "toggle":
            lines.append(f"\n**{txt}**\n")
        elif t == "code":
            lines.append(f"```\n{txt}\n```\n")
        elif t == "divider":
            lines.append("\n---\n")
        elif t == "to_do":
            done = (p.get("checked") or [["No"]])[0][0] == "Yes"
            lines.append(f"{pad}- [{'x' if done else ' '}] {txt}")
        elif t in ("image", "video", "embed", "bookmark", "file"):
            src = (p or {}).get("source", [[""]])[0][0]
            lines.append(f"\n（{t}：{src}）\n")
        elif t == "page" and bid != dashed(pid):
            lines.append(f"\n**〔子頁〕{txt}**\n")
            return
        if t != "numbered_list":
            num = 0
        for c in v.get("content", []) or []:
            walk(c, depth + (1 if t in ("bulleted_list", "numbered_list", "to_do") else 0))

    for c in root.get("content", []) or []:
        walk(c)
    return "\n".join(lines)


def title_of(pid, blocks):
    return rt(val_of(blocks.get(dashed(pid), {})).get("properties", {})) or pid


def safe(name):
    return re.sub(r'[/\\:*?"<>|]', "－", name).strip()[:80] or "untitled"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--page", action="append", default=[], help="頁面 id，可重複")
    ap.add_argument("--list", help="列出這頁裡的 collection / view id 後結束")
    ap.add_argument("--collection")
    ap.add_argument("--view")
    ap.add_argument("--limit", type=int, default=200)
    a = ap.parse_args()

    if a.list:
        rm = api("loadPageChunk", {"pageId": dashed(a.list), "limit": 200,
                                   "cursor": {"stack": []}, "chunkNumber": 0,
                                   "verticalColumns": False})["recordMap"]
        for k in ("collection", "collection_view"):
            print(f"== {k}")
            for cid, v in rm.get(k, {}).items():
                val = val_of(v)
                nm = val.get("name")
                print("  ", cid, "|", nm[0][0] if nm else val.get("type", ""))
        return

    targets = [(p, None) for p in a.page]
    if a.collection and a.view:
        d = api("queryCollection", {
            "collection": {"id": a.collection}, "collectionView": {"id": a.view},
            "loader": {"type": "reducer",
                       "reducers": {"collection_group_results":
                                    {"type": "results", "limit": a.limit}},
                       "searchQuery": "", "userTimeZone": "Asia/Taipei"}})
        for bid, v in d.get("recordMap", {}).get("block", {}).items():
            val = val_of(v)
            if val.get("type") == "page":
                t = rt(val.get("properties", {}))
                if t:
                    targets.append((bid, t))

    seen, uniq = set(), []
    for pid, t in targets:
        if pid not in seen:
            seen.add(pid)
            uniq.append((pid, t))

    os.makedirs(a.out, exist_ok=True)
    print(f"共 {len(uniq)} 頁要抓")
    ok = 0
    for i, (pid, t) in enumerate(uniq, 1):
        try:
            title = t
            fn = os.path.join(a.out, safe(title) + ".md") if title else None
            if fn and os.path.exists(fn) and os.path.getsize(fn) > 400:
                print(f"[{i}/{len(uniq)}] SKIP {title[:34]}")
                ok += 1
                continue
            blocks = load_page(pid)
            title = title or title_of(pid, blocks)
            fn = os.path.join(a.out, safe(title) + ".md")
            if os.path.exists(fn) and os.path.getsize(fn) > 400:
                print(f"[{i}/{len(uniq)}] SKIP {title[:34]}")
                ok += 1
                continue
            body = to_md(pid, blocks)
            head = (f"# {title}\n\n> 來源：Notion 公開頁\n"
                    f"> https://www.notion.so/{pid.replace('-','')}\n"
                    f"> 若為付費內容，僅供個人學習，請勿外流。\n\n---\n")
            open(fn, "w", encoding="utf-8").write(head + body)
            ok += 1
            print(f"[{i}/{len(uniq)}] OK {title[:34]} — {len(body)} 字")
        except Exception as e:
            print(f"[{i}/{len(uniq)}] FAIL {(t or pid)[:34]} — {e}")
        time.sleep(3.0)
    print(f"DONE {ok}/{len(uniq)} → {a.out}")


if __name__ == "__main__":
    main()
