# EP56｜初見 Gemini 4 Argon 模型｜逐幀筆記交付包

製作：竹貞｜完成日期：2026-11-13

## 來源偵測

- Google Drive 資料夾 ID：`1InQ14lNc2jJIsqBIyhg7Cd8JX9P_qw7l`
- 錄影回放捷徑 ID：`1tksg57QULGSdnvre11A5f9dIrCDIY3mI`
- 實際 MP4 檔案 ID：`1GhuJi-f04ySJG5gk8Jc-VDyXFylr13J4`
- PPTX 檔案 ID：`1xV1mzk6ywT6SxLlGwqtr5Wh34OlUtP55`
- PDF 檔案 ID：`1fSOZPvLXvbyfATIcTm1EHTLNrdZ2y3u_`
- prompts 表 ID：`1kAzc68k84IDPlDoNdr9I6_sUtKo-zTkZ`
- 來源錄影：32:25、1920×1080、24 fps。
- 簡報：PPTX 25 頁；Drive 另附 22 頁 PDF。
- 來源資料夾沒有 SRT／VTT，逐字稿由本機語音辨識產生。

## 交付內容

- `index.html`：整包導覽。
- `課堂筆記頁/ep56-course-notes.html`：正式課堂筆記頁。
- `課堂筆記頁/ep56-ai-skills.html`：互動 AI 任務技能地圖。
- `課堂筆記頁/EP56_正式課堂筆記.pdf`：正式 PDF。
- `課堂筆記頁/EP56_正式課堂筆記.docx`：正式 Word。
- `逐幀筆記/EP56_初見Gemini4Argon模型/`：44 張關鍵畫面 HTML、Markdown、逐字稿與手機 PDF。
- `完整版逐幀筆記/`：130 張每 15 秒影格 HTML、Markdown、逐字稿與手機 PDF。
- `整合筆記/ep56-integrated.html`：25 頁簡報 × 時間軸 × 正式筆記整合版。
- `整合筆記/EP56_簡報整合筆記.pdf`、`.docx`：整合版 PDF／Word。
- `EP56_初見Gemini4Argon模型_筆記包.zip`：不含原始錄影、簡報、ASR JSON、工作檔與未處理影格的乾淨發行包。

## 去識別與公開邊界

- 原始影片、PPTX、PDF、XLSX、示範 DOCX、ASR JSON 與未處理影格不屬於公開素材。
- 44 張關鍵影格與 130 張完整版影格均採固定安全裁切，移除右側參與者、帳號、URL／書籤列與工作列。
- 另有 16 張含本機檔名、分享網址、試算表或裝置設定的畫面，已改為說明卡。
- 公開版 HTML／Markdown 不保留 OCR 原文；只保留已裁切影格與去識別後口述。
- 正式頁與簡報整合頁都註明內容依課程資料整理，不代表獨立產品查核。
- 未宣稱取得原作者授權；若內容涉及權利或隱私疑慮，應下架處理。

## 發布交班

網站可用素材集中在 `課堂筆記頁/`：

- `ep56-course-notes.html`
- `ep56-ai-skills.html`
- `ep56-img/`
- `EP56_正式課堂筆記.pdf`
- `EP56_正式課堂筆記.docx`

此專案只備妥素材，未自行上傳網站、未推 Git、未回存 Drive。
