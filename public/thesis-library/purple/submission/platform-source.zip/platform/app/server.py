"""Private, phone-first research prototype. User traces remain local."""
from pathlib import Path
from datetime import datetime
import json, os, threading, time, uuid, hashlib, copy
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Literal
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')
app = FastAPI(title='紫區：口語知識查找', docs_url=None, redoc_url=None)
CODE_HASH = hashlib.sha256(b''.join(p.read_bytes() for p in sorted((ROOT/'app').glob('*.py')))).hexdigest()
_engine = None
_engine_lock = threading.Lock()
_query_lock = threading.Lock()
_log_lock = threading.Lock()


def engine():
    global _engine
    with _engine_lock:
        if _engine is None:
            from .engine import Engine
            _engine = Engine(ROOT)
    return _engine


class Turn(BaseModel):
    role: Literal['user', 'assistant']
    content: str = Field(max_length=6000)


class Query(BaseModel):
    group: Literal['A', 'B']
    query: str = Field(min_length=1, max_length=500)
    history: list[Turn] = Field(default_factory=list, max_length=12)
    session: str = Field(default='', max_length=80, pattern=r'^[a-zA-Z0-9_-]*$')
    task: str = Field(default='', max_length=120)
    offset: int = Field(default=0, ge=0, le=100000)
    kind: Literal['development', 'smoke'] = 'development'


@app.middleware('http')
async def local_only(request: Request, call_next):
    # Protect against browser cross-site requests/DNS rebinding on a private service.
    host = request.headers.get('host', '').split(':')[0]
    allowed = {'100.83.58.39', '127.0.0.1', 'localhost'}
    allowed.update(x for x in os.environ.get('PURPLE_ALLOWED_HOSTS', '').split(',') if x)
    if os.environ.get('PYTEST_CURRENT_TEST'): allowed.add('testserver')
    if host not in allowed:
        return Response('Invalid host', status_code=400)
    origin = request.headers.get('origin')
    if request.method == 'POST' and origin and origin != f"http://{request.headers.get('host')}":
        return Response('Invalid origin', status_code=403)
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Cache-Control'] = 'no-store'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'"
    if request.url.path == '/architecture-view' and response.status_code == 200:
        # Only this fixed, generated viewer may execute its bundled inline scripts.
        hashes = json.loads((ROOT/'docs/architecture-1023/viewer-csp.json').read_text())['script_hashes']
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; script-src 'self' " + ' '.join(hashes) +
            "; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; "
            "connect-src 'self'; frame-ancestors 'self'; base-uri 'none'; object-src 'none'"
        )
    if request.url.path.startswith('/island/'):
        # Local JS only; Three.js and DOM labels set style attributes at runtime.
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; object-src 'none'"
    return response


app.mount('/island', StaticFiles(directory=ROOT/'static/island', html=True), name='island')


@app.get('/')
def index(): return FileResponse(ROOT / 'static/index.html')


@app.get('/static/{name}')
def asset(name: str):
    if name not in {'app.js', 'style.css', 'architecture.css'}: raise HTTPException(404)
    return FileResponse(ROOT / 'static' / name)


@app.get('/guide.pdf')
def guide_pdf():
    return FileResponse(ROOT/'docs/研究｜紫區平台｜操作與建置說明.pdf', media_type='application/pdf')


@app.get('/guide.docx')
def guide_docx():
    return FileResponse(ROOT/'docs/研究｜紫區平台｜操作與建置說明.docx', filename='purple-guide.docx')


@app.get('/architecture')
def architecture_page():
    return FileResponse(ROOT/'static/architecture.html')


@app.get('/architecture-view')
def architecture_view():
    html = (ROOT/'docs/architecture-1023/purple-architecture.html').read_bytes()
    expected = json.loads((ROOT/'docs/architecture-1023/viewer-csp.json').read_text())['html_sha256']
    if hashlib.sha256(html).hexdigest() != expected: raise HTTPException(503, '架構圖版本待驗證')
    return Response(html, media_type='text/html')


@app.get('/architecture-source')
def architecture_source():
    return FileResponse(ROOT/'docs/architecture-1023/candidate.json', filename='purple-architecture.json')


@app.get('/architecture.png')
def architecture():
    return FileResponse(ROOT/'docs/研究｜紫區平台｜架構圖.png', media_type='image/png')


@app.get('/api/status')
def status():
    return {'version': '0.1.1', 'code_hash': CODE_HASH, 'research_stage': 'development', **engine().status()}


@app.get('/api/document/{doc_id:path}')
def document(doc_id: str):
    found = engine().document(doc_id)
    if found is None: raise HTTPException(404, '找不到此來源')
    return found


def record(data):
    dest = ROOT / 'results/demo_log'
    dest.mkdir(parents=True, exist_ok=True)
    f = dest / (datetime.now().strftime('%Y%m%d') + '.jsonl')
    with _log_lock:
        fd = os.open(f, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        with os.fdopen(fd, 'a', encoding='utf-8') as out:
            out.write(json.dumps(data, ensure_ascii=False) + '\n')
            out.flush(); os.fsync(out.fileno())


@app.post('/api/query')
def query(req: Query):
    if not req.query.strip(): raise HTTPException(422, '請輸入查找文字或問題')
    locked = req.group == 'B'
    if locked and not _query_lock.acquire(blocking=False): raise HTTPException(429, '正在處理上一個問題，請稍後再試')
    start = time.monotonic(); run_id = str(uuid.uuid4())
    try:
        e = engine()
        if req.group == 'A': result = e.literal(req.query, offset=req.offset, limit=20)
        else: result = e.ask(req.query, [t.model_dump() for t in req.history])
        result = {**result, 'run_id': run_id, 'group': req.group, 'elapsed_seconds': round(time.monotonic()-start, 3)}
        return logged_response(req, result)
    except HTTPException: raise
    except Exception as exc:
        # Never expose provider response bodies, key values or environment.
        result = {'status': 'error', 'answer': '這次處理未完成，請稍後重試。原問題已保留。', 'error_type': type(exc).__name__, 'run_id': run_id}
        return logged_response(req, result)
    finally:
        if locked: _query_lock.release()



def logged_response(req, result):
    try:
        record({'at': datetime.now().astimezone().isoformat(), 'version': '0.1.1', 'code_hash': CODE_HASH, 'request': req.model_dump(), 'result': result})
        saved = True
    except OSError:
        saved = False
    public = copy.deepcopy(result)
    trace = public.get('trace', {})
    for call in trace.get('llm_calls', []):
        call.pop('raw_text', None); call.pop('parsed', None)
    trace.pop('evidence', None)
    public['log_saved'] = saved
    if not saved: public['log_warning'] = '答案已產生，但紀錄未儲存；本次不可當研究資料。'
    return public

@app.get('/api/export')
def export():
    # Export only a deliberately small, sanitized grading table; raw traces stay local.
    import csv, io
    stream = io.StringIO(); stream.write('\ufeff')
    writer = csv.writer(stream)
    writer.writerow(['紀錄編號','時間','階段','任務','組別','問題','狀態','命中段落','引用數','秒數','答案正確0至2','引用支持0至2','備註'])
    for path in sorted((ROOT/'results/demo_log').glob('*.jsonl')):
        for line in path.read_text(encoding='utf-8').splitlines():
            try: row=json.loads(line)
            except ValueError: continue
            req=row.get('request',{}); res=row.get('result',{})
            values=[res.get('run_id',''),row.get('at',''),req.get('kind',''),req.get('task',''),req.get('group',''),req.get('query',''),res.get('status','literal'),res.get('total',''),len(res.get('citations',[])),res.get('elapsed_seconds',''),'','','']
            # Prevent spreadsheet formula execution in user-controlled cells.
            writer.writerow([("'"+v if v.lstrip().startswith(('=','+','-','@')) else v) if isinstance(v,str) else v for v in values])
    return Response(stream.getvalue(), media_type='text/csv; charset=utf-8', headers={'Content-Disposition':'attachment; filename="purple-review.csv"'})
