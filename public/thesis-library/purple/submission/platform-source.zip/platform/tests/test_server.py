from fastapi.testclient import TestClient
from app import server

class Stub:
    def literal(self,q,offset=0,limit=20):return {'query':q,'total':0,'hits':[]}
    def ask(self,q,history):return {'status':'clarify','answer':'請補充條件','citations':[]}
    def status(self):return {'n_docs':2}
    def document(self,id):return None

def test_private_origin_and_host(monkeypatch):
    monkeypatch.setattr(server,'_engine',Stub())
    client=TestClient(server.app)
    assert client.get('/',headers={'host':'evil.example'}).status_code==400
    assert client.post('/api/query',headers={'origin':'https://evil.example'},json={'group':'B','query':'hi'}).status_code==403

def test_validation_and_exact_input(monkeypatch):
    monkeypatch.setattr(server,'_engine',Stub()); rows=[]
    monkeypatch.setattr(server,'record',rows.append)
    client=TestClient(server.app)
    assert client.post('/api/query',json={'group':'A','query':'  '}).status_code==422
    assert client.post('/api/query',json={'group':'C','query':'x'}).status_code==422
    r=client.post('/api/query',json={'group':'A','query':'育嬰 如何'}).json()
    assert r['query']=='育嬰 如何' and rows[0]['request']['query']=='育嬰 如何'
    assert client.get('/api/document/missing').status_code==404

def test_failure_does_not_expose_exception_body(monkeypatch):
    class Failing(Stub):
        def ask(self,*args):raise ValueError('secret-key-should-never-leak')
    monkeypatch.setattr(server,'_engine',Failing());rows=[];monkeypatch.setattr(server,'record',rows.append)
    response=TestClient(server.app).post('/api/query',json={'group':'B','query':'x'})
    assert response.json()['status']=='error'
    assert 'secret-key' not in response.text and 'secret-key' not in str(rows)

def test_log_failure_returns_answer_and_warning(monkeypatch):
    monkeypatch.setattr(server,'_engine',Stub())
    def disk_full(_):raise OSError('disk full')
    monkeypatch.setattr(server,'record',disk_full)
    r=TestClient(server.app).post('/api/query',json={'group':'B','query':'x'})
    assert r.status_code==200
    assert r.json()['answer']=='請補充條件' and r.json()['log_saved'] is False

def test_raw_model_output_is_logged_but_not_delivered(monkeypatch):
    class Raw(Stub):
        def ask(self,*args):return {'status':'insufficient','answer':'資料不足','trace':{'llm_calls':[{'raw_text':'unverified','parsed':{'url':'https://invalid.example'}}],'evidence':'raw evidence'}}
    monkeypatch.setattr(server,'_engine',Raw());rows=[];monkeypatch.setattr(server,'record',rows.append)
    r=TestClient(server.app).post('/api/query',json={'group':'B','query':'x'})
    assert 'raw_text' not in r.text and 'invalid.example' not in r.text
    assert rows[0]['result']['trace']['llm_calls'][0]['raw_text']=='unverified'

def test_literal_runs_while_ai_is_busy(monkeypatch):
    monkeypatch.setattr(server,'_engine',Stub());monkeypatch.setattr(server,'record',lambda _:None)
    server._query_lock.acquire()
    try:
        client=TestClient(server.app)
        assert client.post('/api/query',json={'group':'A','query':'x'}).status_code==200
        assert client.post('/api/query',json={'group':'B','query':'x'}).status_code==429
    finally:server._query_lock.release()


def test_architecture_viewer_is_pinned_and_policy_is_scoped():
    import hashlib, json, re, base64
    client = TestClient(server.app)
    view = client.get('/architecture-view')
    assert view.status_code == 200
    manifest = json.loads((server.ROOT/'docs/architecture-1023/viewer-csp.json').read_text())
    assert hashlib.sha256(view.content).hexdigest() == manifest['html_sha256']
    actual = ["'sha256-" + base64.b64encode(hashlib.sha256(b.encode()).digest()).decode() + "'"
              for b in re.findall(r'<script\b[^>]*>(.*?)</script>', view.text, re.S | re.I)]
    assert actual == manifest['script_hashes']
    policy = view.headers['content-security-policy']
    assert "frame-ancestors 'self'" in policy and all(h in policy for h in actual)
    assert "'unsafe-inline'" not in policy.split('script-src', 1)[1].split(';', 1)[0]
    for path in ['/', '/architecture', '/architecture-source', '/static/architecture.css']:
        response = client.get(path)
        assert response.status_code == 200
        assert "frame-ancestors 'none'" in response.headers['content-security-policy']
        assert "'unsafe-inline'" not in response.headers['content-security-policy']
    assert client.get('/static/.env').status_code == 404


def test_island_static_view_keeps_engine_and_private_policy_separate(monkeypatch):
    def forbidden(): raise AssertionError('Island must not load query engine')
    monkeypatch.setattr(server, 'engine', forbidden)
    client = TestClient(server.app)
    response = client.get('/island/')
    assert response.status_code == 200 and 'Tarshar 的研究同樂會' in response.text
    policy = response.headers['content-security-policy']
    assert "script-src 'self';" in policy and "frame-ancestors 'none'" in policy
    data = client.get('/island/data.json').json()
    assert len(data['islands']) == 5 and data['events'] == []
    assert client.get('/island/vendor/three.module.js').status_code == 200
    assert client.get('/island/%2e%2e/%2e%2e/.env').status_code == 404
    assert "'unsafe-inline'" not in client.get('/').headers['content-security-policy']
