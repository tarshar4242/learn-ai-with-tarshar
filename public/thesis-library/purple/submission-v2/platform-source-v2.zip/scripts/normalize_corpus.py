"""E1: deterministic shared-corpus cleanup, with raw evidence and offset mapping.

No query normalization, Unicode width conversion, network access, or production
corpus overwrite. The candidate is promoted by the integration owner for BOTH
retrieval groups. Offsets are zero-based Python Unicode code points, half-open.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

SOURCE_SHA256 = "3beff8975506e157fbab89e61035788171909a0b0eb4fae16ec9550be67674c0"
VERSION = "e1-common-corpus-normalization-v1"
CJK = "\\u3400-\\u9fff\\uf900-\\ufaff\\U00020000-\\U0002fa1f"
HARD_BREAK = re.compile(rf"(?<=[{CJK}])\n(?=[{CJK}])")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def contiguous_segments(offsets):
    """Compact normalized index -> original index mapping; all characters survive verbatim."""
    segments = []
    for normalized_offset, raw_offset in enumerate(offsets):
        if segments and segments[-1][3] == raw_offset:
            segments[-1][1] += 1
            segments[-1][3] += 1
        else:
            segments.append([normalized_offset, normalized_offset + 1, raw_offset, raw_offset + 1])
    return segments


def normalize_document(document):
    result = copy.deepcopy(document)
    raw = document["text"]
    offsets = [i for i, char in enumerate(raw) if char != "\r"]
    current = "".join(raw[i] for i in offsets)
    removed = {i: "carriage_return" for i, char in enumerate(raw) if char == "\r"}
    duplicate_removed = False
    # Identify the structural separator BEFORE joining CJK line breaks. Only
    # identical abstracts are collapsed; nonidentical full text is never dropped.
    if document.get("type") == "函釋" and current.startswith("要旨："):
        split = current.find("\n全文：")
        if split >= 0 and current[3:split] == current[split + len("\n全文："):]:
            duplicate_removed = True
            for index in offsets[split:]:
                removed[index] = "duplicate_abstract_presented_as_full_text"
            offsets = offsets[:split]
            current = current[:split]
            result["type"] = "函釋要旨索引"
    hard_positions = {match.start() for match in HARD_BREAK.finditer(current)}
    for position in hard_positions:
        removed[offsets[position]] = "single_lf_between_cjk"
    offsets = [index for position, index in enumerate(offsets) if position not in hard_positions]
    result["text"] = "".join(raw[index] for index in offsets)
    # A repeated character-level pass is unnecessary: each removed LF has a CJK
    # character on either side. Blank lines and all non-CJK boundaries survive.
    deletions = []
    for position in sorted(removed):
        reason = removed[position]
        if deletions and deletions[-1]["raw_end"] == position and deletions[-1]["reason"] == reason:
            deletions[-1]["raw_end"] += 1
        else:
            deletions.append({"raw_start": position, "raw_end": position + 1, "reason": reason})
    mapping = {
        "id": document["id"], "raw_text": raw, "normalized_text": result["text"],
        "raw_type": document.get("type"), "normalized_type": result.get("type"),
        "raw_text_sha256": sha256(raw.encode()),
        "normalized_text_sha256": sha256(result["text"].encode()),
        "segments": contiguous_segments(offsets), "deleted_spans": deletions,
        "removed_cr": raw.count("\r"), "joined_single_cjk_breaks": len(hard_positions),
        "duplicate_abstract_removed": duplicate_removed,
    }
    return result, mapping


def normalize_corpus(corpus):
    candidate = copy.deepcopy(corpus)
    pairs = [normalize_document(doc) for doc in corpus["docs"]]
    candidate["docs"] = [doc for doc, _ in pairs]
    return candidate, [mapping for _, mapping in pairs]


def corpus_statistics(corpus):
    docs = corpus["docs"]
    duplicates = []
    for doc in docs:
        current = doc["text"].replace("\r", "")
        split = current.find("\n全文：")
        if current.startswith("要旨：") and split >= 0 and current[3:split] == current[split + 4:]:
            duplicates.append(doc["id"])
    return {
        "documents": len(docs), "types": dict(Counter(doc.get("type") for doc in docs)),
        "cr_characters": sum(doc["text"].count("\r") for doc in docs),
        "cjk_hard_break_documents": sum(bool(HARD_BREAK.search(doc["text"].replace("\r", ""))) for doc in docs),
        "duplicate_abstract_documents": len(duplicates), "duplicate_abstract_ids": duplicates,
    }


def literal_statistics(corpus, query):
    """Same exact, nonoverlapping, separate-title/text count as Engine.literal."""
    matched = []
    for doc in corpus["docs"]:
        title = f"{doc.get('law', '')} {doc.get('no', '')}".strip()
        total = title.count(query) + doc["text"].count(query)
        if total:
            matched.append({"id": doc["id"], "occurrences": total})
    return {"query": query, "matched_documents": len(matched),
            "occurrences": sum(doc["occurrences"] for doc in matched), "matches": matched}


def build(source: Path, output: Path, expected_sha256=SOURCE_SHA256):
    raw_bytes = source.read_bytes()
    old_hash = sha256(raw_bytes)
    if old_hash != expected_sha256:
        raise ValueError(f"Source SHA256 mismatch: expected {expected_sha256}, got {old_hash}")
    corpus = json.loads(raw_bytes)
    candidate, mappings = normalize_corpus(corpus)
    candidate_bytes = json_bytes(candidate)
    new_hash = sha256(candidate_bytes)
    output.mkdir(parents=True, exist_ok=True)
    snapshot = output / f"source-{old_hash}.json"
    if snapshot.exists() and snapshot.read_bytes() != raw_bytes:
        raise ValueError("Existing source snapshot differs; refusing to overwrite original evidence")
    snapshot.write_bytes(raw_bytes)
    (output / "corpus-normalized.json").write_bytes(candidate_bytes)
    mapping_bytes = "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in mappings).encode()
    (output / "text-offset-mapping.jsonl").write_bytes(mapping_bytes)
    audit = {
        "version": VERSION, "purpose": "development-only; not formal experiment results",
        "source_sha256": old_hash, "normalized_sha256": new_hash,
        "script_sha256": sha256(Path(__file__).read_bytes()),
        "source_snapshot": snapshot.name, "candidate": "corpus-normalized.json",
        "mapping_file": "text-offset-mapping.jsonl", "mapping_sha256": sha256(mapping_bytes),
        "offset_convention": "zero-based Unicode code points; half-open; segments=[normalized_start,normalized_end,raw_start,raw_end]",
        "rules": ["remove CR", "join single LF strictly between CJK characters", "retain blank-line paragraph boundaries", "retain one identical abstract and label 函釋要旨索引", "no width, number, punctuation, case, whitespace, or query normalization"],
        "before": corpus_statistics(corpus), "after": corpus_statistics(candidate),
        "modified_text_documents": sum(m["raw_text"] != m["normalized_text"] for m in mappings),
        "modified_type_documents": sum(m["raw_type"] != m["normalized_type"] for m in mappings),
        "idempotent": normalize_corpus(candidate)[0] == candidate,
        "literal_development_comparisons": [
            {"before": literal_statistics(corpus, query), "after": literal_statistics(candidate, query)}
            for query in ("育嬰", "育嬰留職停薪", "育嬰假如何請", "企業雇主")
        ],
        "limitations": [
            "CJK adjacency is a deterministic layout heuristic, not a reconstruction of authoritative paragraph semantics.",
            "Blank lines remain intact; single LF adjacent to punctuation, Latin text, digits or indentation is intentionally retained.",
            "Existing fullwidth/halfwidth, Arabic/Chinese-number differences are unchanged and require a researcher decision.",
            "Duplicate abstracts are not newly acquired full official interpretations; the index label makes this limitation explicit.",
            "Raw and normalized texts are both retained. Runtime must promote the same candidate for A and B; this script does not modify live corpus or manifest.",
            "The corpus top-level report is inherited source metadata, not a new normalization audit. This file is the current E1 audit.",
        ],
    }
    (output / "normalization-audit.json").write_bytes(json_bytes(audit))
    return audit


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=root / "data/corpus.json")
    parser.add_argument("--output-dir", type=Path, default=root / "data/normalization")
    parser.add_argument("--expected-sha256", default=SOURCE_SHA256)
    args = parser.parse_args()
    audit = build(args.source, args.output_dir, args.expected_sha256)
    print(json.dumps({k: audit[k] for k in ("source_sha256", "normalized_sha256", "before", "after", "idempotent")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
