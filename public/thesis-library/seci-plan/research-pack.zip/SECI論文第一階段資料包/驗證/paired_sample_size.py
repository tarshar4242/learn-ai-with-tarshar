#!/usr/bin/env python3
"""Reproduce planning scenarios for a two-sided paired t test.

Run: python3 paired_sample_size.py
Requires existing SciPy; no packages are installed by this script.
These are planning calculations, not observed study results or final sample sizes.
"""

import json
import math
import hashlib
from pathlib import Path

import scipy
from scipy.optimize import brentq
from scipy.stats import nct, t


ALPHA = 0.05
TARGET_POWER = 0.80


def paired_power(n, dz):
    """P(reject H0), df=n-1 and noncentrality=dz*sqrt(n)."""
    df = n - 1
    critical = t.ppf(1 - ALPHA / 2, df)
    noncentrality = dz * math.sqrt(n)
    return float(
        nct.sf(critical, df, noncentrality)
        + nct.cdf(-critical, df, noncentrality)
    )


def main():
    sample_size = []
    # Power increases with n for these fixed-effect t-test scenarios. Even the
    # largest effect has insufficient power at n=5, so no smaller n can qualify.
    # Starting here avoids SciPy 1.13.1 low-df Boost warnings at n=2 and n=4.
    assert paired_power(5, 0.80) < TARGET_POWER
    for dz in (0.30, 0.50, 0.60, 0.80):
        n = next(n for n in range(5, 1001) if paired_power(n, dz) >= TARGET_POWER)
        actual = paired_power(n, dz)
        previous = paired_power(n - 1, dz)
        assert previous < TARGET_POWER <= actual
        sample_size.append({
            "assumed_dz": dz,
            "minimum_complete_participants": n,
            "achieved_power": actual,
            "power_with_one_fewer_participant": previous,
        })

    sensitivity = []
    for n in (10, 12, 15, 24, 34, 36):
        dz = float(brentq(lambda d: paired_power(n, d) - TARGET_POWER, 0.01, 2.0))
        assert abs(paired_power(n, dz) - TARGET_POWER) < 1e-8
        sensitivity.append({
            "complete_participants": n,
            "dz_for_80_percent_power": dz,
            "power_if_dz_equals_0_50": paired_power(n, 0.50),
        })

    script = Path(__file__)
    result = {
        "status": "討論用規劃算例；未核定正式樣本；非實驗結果",
        "method": "Exact noncentral t rejection probability, two-sided paired t test",
        "scipy_version": scipy.__version__,
        "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
        "alpha": ALPHA,
        "target_power": TARGET_POWER,
        "effect_definition": "dz = mean within-participant difference / SD of differences",
        "sample_unit": "one complete pair per participant; raters and cards are not independent participants",
        "assumptions": [
            "Independent participant differences, modeled as normally distributed",
            "One prespecified primary paired comparison; no multiplicity adjustment",
            "No unmodeled material carryover, period, or case confounding",
            "No missing-pair inflation is included in the minimum complete-participant estimates",
            "Not an independent-groups or mixed-model sample-size calculation",
            "Assumed effect sizes are planning scenarios, not expected true AI effects",
        ],
        "sample_size_scenarios": sample_size,
        "sensitivity_scenarios": sensitivity,
        "recruitment_scenario": {
            "complete_participants": 36,
            "assumed_noncompletion_fraction": 0.10,
            "planned_recruitment": math.ceil(36 / (1 - 0.10)),
            "note": "四序平衡與10%未完成假設；不保證招募40人即可取得36份可評分完整配對",
        },
        "references": [
            "https://doi.org/10.1525/collabra.33267",
            "https://www.psychologie.hhu.de/fileadmin/redaktion/Fakultaeten/Mathematisch-Naturwissenschaftliche_Fakultaet/Psychologie/AAP/gpower/GPowerManual.pdf",
        ],
    }
    output = script.with_name("sample_size_results.json")
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
