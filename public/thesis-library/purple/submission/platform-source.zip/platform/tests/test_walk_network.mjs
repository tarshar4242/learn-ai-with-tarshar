import assert from 'node:assert/strict';
import {makeWalkNetwork,makeTour,sampleTour,WALK_Y} from '../static/island/walk-network.js';
import fs from 'node:fs';
import {islandPosition,ISLAND_RADIUS,PATH_RADIUS,PATH_WIDTH,ISLAND_SPACING} from '../static/island/world-layout.js';
const data=JSON.parse(fs.readFileSync(new URL('../static/island/data.json',import.meta.url)));
const islands=data.islands.map(i=>({...i,...islandPosition(i.axial)}));
const network=makeWalkNetwork(islands),tour=makeTour(network,islands,data.avatar.route);assert.equal(network.nodes.length,60);
const visited=new Set();let bridgeSamples=0;for(let d=0;d<tour.length;d+=.025){const p=sampleTour(network,tour,d),q=sampleTour(network,tour,d+.025);visited.add(p.islandId);assert(Math.hypot(p.x-q.x,p.z-q.z)<=.02501);assert(p.y>=WALK_Y&&p.y<=WALK_Y+.10001);if(p.kind==='bridge')bridgeSamples++;}
assert.equal(visited.size,5);assert(bridgeSamples>0);const a=sampleTour(network,tour,0),b=sampleTour(network,tour,tour.length);assert.deepEqual([a.x,a.y,a.z],[b.x,b.y,b.z]);
console.log(JSON.stringify({nodes:60,bridges:network.edges.filter(e=>e.kind==='bridge').length,tourLength:tour.length,visited:[...visited],bridgeSamples,continuousLoop:true},null,2));

assert(PATH_RADIUS+PATH_WIDTH/2<ISLAND_RADIUS);assert(ISLAND_SPACING>ISLAND_RADIUS);
